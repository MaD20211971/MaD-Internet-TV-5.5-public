package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.foundation.BorderStroke
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ChannelItem
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentRose
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class RadioRegionFilter(val labelDe: String, val labelEn: String) {
    ALL("Alle Radiosender", "All Stations"),
    GERMANY("🇩🇪 Deutschland", "🇩🇪 Germany"),
    AUSTRIA("🇦🇹 Österreich", "🇦🇹 Austria"),
    SWITZERLAND("🇨🇭 Schweiz", "🇨🇭 Switzerland"),
    POP_CHARTS("🎵 Pop & Hits", "🎵 Pop & Hits"),
    ROCK_METAL("🎸 Rock & Alternative", "🎸 Rock & Metal"),
    KLASSIK_KULTUR("🎻 Klassik & Kultur", "🎻 Classical & Culture"),
    INFO_NEWS("📰 Info & Nachrichten", "📰 News & Talk"),
    SCHLAGER("🎉 Schlager & Volksmusik", "🎉 Schlager"),
    ELECTRONIC("⚡ Electro & Dance", "⚡ Dance & EDM"),
    INTERNATIONAL("🌍 International", "🌍 International")
}

@Composable
fun RadioExplorer(
    radioStations: List<ChannelItem>,
    onPlayRadio: (ChannelItem) -> Unit,
    onToggleFavorite: ((ChannelItem) -> Unit)? = null,
    isEnglish: Boolean = false,
    modifier: Modifier = Modifier
) {
    var selectedFilter by remember { mutableStateOf(RadioRegionFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }

    // Filter and sort radio stations: Priority: DE -> AT -> CH -> Others
    val filteredStations = remember(radioStations, selectedFilter, searchQuery) {
        var list = when (selectedFilter) {
            RadioRegionFilter.ALL -> radioStations
            RadioRegionFilter.GERMANY -> radioStations.filter { it.countryCode == "DE" || it.isDach && it.countryCode != "AT" && it.countryCode != "CH" }
            RadioRegionFilter.AUSTRIA -> radioStations.filter { it.countryCode == "AT" }
            RadioRegionFilter.SWITZERLAND -> radioStations.filter { it.countryCode == "CH" }
            RadioRegionFilter.POP_CHARTS -> radioStations.filter {
                val g = "${it.name} ${it.groupTitle}".uppercase()
                g.contains("POP") || g.contains("HIT") || g.contains("CHARTS") || g.contains("TOP") || g.contains("ANTENNE")
            }
            RadioRegionFilter.ROCK_METAL -> radioStations.filter {
                val g = "${it.name} ${it.groupTitle}".uppercase()
                g.contains("ROCK") || g.contains("METAL") || g.contains("ALTERNATIVE") || g.contains("GUITAR")
            }
            RadioRegionFilter.KLASSIK_KULTUR -> radioStations.filter {
                val g = "${it.name} ${it.groupTitle}".uppercase()
                g.contains("KLASSIK") || g.contains("KULTUR") || g.contains("JAZZ") || g.contains("CLASSIC")
            }
            RadioRegionFilter.INFO_NEWS -> radioStations.filter {
                val g = "${it.name} ${it.groupTitle}".uppercase()
                g.contains("INFO") || g.contains("NEWS") || g.contains("AKTUELL") || g.contains("DLF") || g.contains("FUNK") || g.contains("INFORADIO")
            }
            RadioRegionFilter.SCHLAGER -> radioStations.filter {
                val g = "${it.name} ${it.groupTitle}".uppercase()
                g.contains("SCHLAGER") || g.contains("VOLK") || g.contains("HEIMAT") || g.contains("PALOMA") || g.contains("BALLERMANN")
            }
            RadioRegionFilter.ELECTRONIC -> radioStations.filter {
                val g = "${it.name} ${it.groupTitle}".uppercase()
                g.contains("ELECTRO") || g.contains("DANCE") || g.contains("HOUSE") || g.contains("TECHNO") || g.contains("SUNSHINE") || g.contains("EDM")
            }
            RadioRegionFilter.INTERNATIONAL -> radioStations.filter { !it.isDach && it.countryCode != "DE" && it.countryCode != "AT" && it.countryCode != "CH" }
        }

        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list = list.filter {
                it.name.lowercase().contains(q) || it.groupTitle.lowercase().contains(q)
            }
        }

        list.sortedWith(
            compareBy<ChannelItem> { it.dachSortRank }
                .thenBy { it.name.lowercase() }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("radio_explorer_view")
    ) {
        // TOP HEADER / SEARCH & BANNER
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Header Stats & Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(AccentCyan, GoldPrimary)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Radio,
                            contentDescription = "Radio",
                            tint = ObsidianBlack,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = if (isEnglish) "Radio Stations" else "Radiosender",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = if (isEnglish) "${filteredStations.size} of ${radioStations.size} Stations • Live Audio" else "${filteredStations.size} von ${radioStations.size} Sendern • Live Audio",
                            fontSize = 12.sp,
                            color = GoldLight
                        )
                    }
                }

                // Live Audio Wave Badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AccentCyan.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AccentCyan.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.FiberManualRecord,
                            contentDescription = null,
                            tint = AccentCyan,
                            modifier = Modifier.size(10.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "LIVE AUDIO",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("radio_search_input"),
                placeholder = {
                    Text(
                        text = if (isEnglish) "Search radio station (1LIVE, SWR3, Antenne...)" else "Radiosender suchen (1LIVE, SWR3, Antenne Bayern...)",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Suche",
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurfaceElevated,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = BorderGlow,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
        }

        // CATEGORY FILTER CHIPS
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(RadioRegionFilter.values()) { filter ->
                val isSelected = selectedFilter == filter
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedFilter = filter },
                    label = {
                        Text(
                            text = if (isEnglish) filter.labelEn else filter.labelDe,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GoldPrimary,
                        selectedLabelColor = ObsidianBlack,
                        containerColor = DarkSurface,
                        labelColor = TextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        borderColor = if (isSelected) GoldPrimary else BorderGlow,
                        selectedBorderColor = GoldPrimary,
                        enabled = true,
                        selected = isSelected
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("radio_filter_${filter.name.lowercase()}")
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // STATIONS GRID
        if (filteredStations.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Radio,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isEnglish) "No radio stations found" else "Keine Radiosender gefunden",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isEnglish) "Try adjusting your search or category filter." else "Passe deine Suche oder den Kategoriefilter an.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp)
                    .testTag("radio_grid"),
                contentPadding = PaddingValues(top = 4.dp, bottom = 80.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(
                    items = filteredStations,
                    key = { it.id },
                    contentType = { "radio_card" }
                ) { station ->
                    RadioCard(
                        station = station,
                        onPlay = { onPlayRadio(station) },
                        onToggleFavorite = onToggleFavorite?.let { cb -> { cb(station) } }
                    )
                }
            }
        }
    }
}

@Composable
fun RadioCard(
    station: ChannelItem,
    onPlay: () -> Unit,
    onToggleFavorite: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, BorderGlow, RoundedCornerShape(14.dp))
            .clickable { onPlay() }
            .testTag("radio_card_${station.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkNavyCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Top Row: Region Tag & Favorite Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val flag = when (station.countryCode) {
                    "DE" -> "🇩🇪 DE"
                    "AT" -> "🇦🇹 AT"
                    "CH" -> "🇨🇭 CH"
                    else -> if (station.isDach) "🇩🇪 DE" else "🌍 INT"
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DarkSurfaceElevated
                ) {
                    Text(
                        text = flag,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                if (onToggleFavorite != null) {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "Favorit",
                            tint = if (station.isFavorite) GoldPrimary else TextMuted.copy(alpha = 0.5f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Station Artwork / Icon Container
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .align(Alignment.CenterHorizontally)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                DarkSurfaceElevated,
                                DarkSurface
                            )
                        )
                    )
                    .border(1.5.dp, GoldPrimary.copy(alpha = 0.6f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (!station.logoUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = station.logoUrl,
                        contentDescription = station.name,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Audiotrack,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Station Name
            Text(
                text = station.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )

            // Category / Genre
            Text(
                text = station.groupTitle.ifBlank { "Radio" },
                fontSize = 11.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Play Action Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(GoldPrimary.copy(alpha = 0.15f))
                    .clickable { onPlay() }
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Abspielen",
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Anhören",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldPrimary
                )
            }
        }
    }
}
