package com.example.ui.components

import android.content.res.Configuration
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.data.model.ChannelItem
import com.example.data.model.EpgProgram
import com.example.data.parser.EpgSyncState
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.max
import kotlin.math.min

private val NavyDark = DarkNavyBackground
private val SurfaceCard = DarkNavyCard
private val NavyDeep = DarkSurface
private val SurfaceHover = DarkSurfaceElevated
private val GlassBorder = BorderSubtle
private val ElectricBlue = AccentCyan
private val CyberCyan = GoldPrimary

private fun formatEpgTime(timestampMs: Long, timezoneId: String): String {
    return try {
        val sdf = SimpleDateFormat("HH:mm", Locale.GERMANY)
        sdf.timeZone = TimeZone.getTimeZone(timezoneId.ifBlank { "Europe/Berlin" })
        sdf.format(Date(timestampMs))
    } catch (_: Exception) {
        val sdf = SimpleDateFormat("HH:mm", Locale.GERMANY)
        sdf.format(Date(timestampMs))
    }
}

private enum class EpgDisplayMode {
    GRID,
    SINGLE_CHANNEL
}

private data class SelectedProgramDetail(
    val channel: ChannelItem,
    val program: EpgProgram
)

@Composable
fun EpgGuideView(
    channels: List<ChannelItem>,
    onSelectChannel: (ChannelItem) -> Unit,
    epgTimezone: String = "Europe/Berlin",
    epgTimeOffsetHours: Int = 0,
    isEnglish: Boolean = false,
    epgGridMap: Map<String, List<EpgProgram>> = emptyMap(),
    syncState: EpgSyncState = EpgSyncState.Idle,
    onSyncEpg: () -> Unit = {},
    loadChannelSchedule: suspend (ChannelItem) -> List<EpgProgram> = { emptyList() }
) {
    val configuration = LocalConfiguration.current
    val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT
    val density = LocalDensity.current
    val coroutineScope = rememberCoroutineScope()

    var displayMode by remember { mutableStateOf(EpgDisplayMode.GRID) }
    var showOnlyVerified by remember { mutableStateOf(true) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedProgramDetail by remember { mutableStateOf<SelectedProgramDetail?>(null) }

    // Live clock that ticks every 30 seconds
    var currentTickMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(30_000L)
            currentTickMs = System.currentTimeMillis()
        }
    }

    val effectiveNowMs = currentTickMs + (epgTimeOffsetHours * 3600 * 1000L)


    // Strict 100% verified channel check: must have verified status AND non-empty programs in epgGridMap
    val verifiedChannelsCount = remember(channels, epgGridMap) {
        channels.count { ch ->
            val progs = epgGridMap[ch.id]
            !progs.isNullOrEmpty() && (ch.isManualEpgOverride || ch.epgMappingStatus == "MATCHED" || !ch.epgId.isNullOrBlank())
        }
    }

    val filteredChannels = remember(channels, epgGridMap, showOnlyVerified, searchQuery) {
        val base = if (showOnlyVerified) {
            channels.filter { ch ->
                val progs = epgGridMap[ch.id]
                !progs.isNullOrEmpty()
            }
        } else {
            channels
        }

        if (searchQuery.isBlank()) {
            base
        } else {
            val q = searchQuery.trim().lowercase()
            base.filter { ch ->
                ch.name.lowercase().contains(q) ||
                    (ch.groupTitle?.lowercase()?.contains(q) == true) ||
                    (epgGridMap[ch.id]?.any { p -> p.title.lowercase().contains(q) } == true)
            }
        }
    }

    var selectedSingleChannel by remember(filteredChannels) {
        mutableStateOf(filteredChannels.firstOrNull() ?: channels.firstOrNull())
    }

    // Timeline parameters: -2 hours to +18 hours (20 hours total = 40 half-hour slots)
    val halfHourMs = 30 * 60 * 1000L
    val gridStartMs = remember(effectiveNowMs / halfHourMs) {
        val roundedHalfHour = (effectiveNowMs / halfHourMs) * halfHourMs
        roundedHalfHour - (4 * halfHourMs) // 2 hours before current slot
    }
    val totalSlots = 40 // 20 hours
    val gridEndMs = gridStartMs + (totalSlots * halfHourMs)

    val dpPerMinute = if (isPortrait) 3.2f else 3.8f
    val slotWidthDp: Dp = (30f * dpPerMinute).dp
    val totalTimelineWidthDp: Dp = (totalSlots * 30f * dpPerMinute).dp
    val channelColumnWidthDp: Dp = if (isPortrait) 142.dp else 190.dp
    val rowHeightDp: Dp = if (isPortrait) 64.dp else 68.dp

    val horizontalScrollState = rememberScrollState()

    fun scrollToNow() {
        val minutesFromStart = ((effectiveNowMs - gridStartMs) / 60_000f).coerceAtLeast(0f)
        val targetDp = (minutesFromStart * dpPerMinute - 60f).coerceAtLeast(0f).dp
        val targetPx = with(density) { targetDp.roundToPx() }
        coroutineScope.launch {
            horizontalScrollState.animateScrollTo(targetPx)
        }
    }

    // Scroll to "NOW" automatically when the EPG Grid first opens
    LaunchedEffect(gridStartMs) {
        val minutesFromStart = ((effectiveNowMs - gridStartMs) / 60_000f).coerceAtLeast(0f)
        val targetDp = (minutesFromStart * dpPerMinute - 60f).coerceAtLeast(0f).dp
        val targetPx = with(density) { targetDp.roundToPx() }
        horizontalScrollState.scrollTo(targetPx)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(horizontal = if (isPortrait) 8.dp else 14.dp, vertical = 8.dp)
    ) {
        // Top Header & Controls
        Surface(
            color = SurfaceCard,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, GlassBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = if (isEnglish) "📅 EPG Program Grid" else "📅 EPG Programm-Raster",
                            color = TextPrimary,
                            fontSize = if (isPortrait) 15.sp else 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Surface(
                            color = Color(0xFF10B981).copy(alpha = 0.16f),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "100% Verifiziert ($verifiedChannelsCount)",
                                color = Color(0xFF10B981),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Jump to NOW button
                        if (displayMode == EpgDisplayMode.GRID) {
                            Surface(
                                color = Color(0xFFEF4444).copy(alpha = 0.18f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFFEF4444)),
                                modifier = Modifier
                                    .testTag("epg_jump_now_button")
                                    .clickable { scrollToNow() }
                            ) {
                                Text(
                                    text = if (isEnglish) "● NOW" else "● JETZT",
                                    color = Color(0xFFFF6B6B),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                )
                            }
                        }

                        // Sync EPG button
                        val isSyncing = syncState is EpgSyncState.Syncing
                        Surface(
                            color = ElectricBlue.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, ElectricBlue),
                            modifier = Modifier
                                .testTag("epg_sync_now_button")
                                .clickable(enabled = !isSyncing) { onSyncEpg() }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (isSyncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(12.dp),
                                        strokeWidth = 2.dp,
                                        color = ElectricBlue
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = "EPG Sync",
                                        tint = ElectricBlue,
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                                Text(
                                    text = if (isSyncing) "Sync..." else "EPG Sync",
                                    color = ElectricBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Filter & Mode Row + Search Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Grid vs Single-Channel toggle
                    Surface(
                        color = if (displayMode == EpgDisplayMode.GRID) ElectricBlue.copy(alpha = 0.22f) else NavyDeep,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, if (displayMode == EpgDisplayMode.GRID) ElectricBlue else GlassBorder),
                        modifier = Modifier
                            .testTag("epg_mode_grid_button")
                            .clickable { displayMode = EpgDisplayMode.GRID }
                    ) {
                        Text(
                            text = if (isEnglish) "📊 Grid" else "📊 EPG-Raster",
                            color = if (displayMode == EpgDisplayMode.GRID) ElectricBlue else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }

                    Surface(
                        color = if (displayMode == EpgDisplayMode.SINGLE_CHANNEL) ElectricBlue.copy(alpha = 0.22f) else NavyDeep,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, if (displayMode == EpgDisplayMode.SINGLE_CHANNEL) ElectricBlue else GlassBorder),
                        modifier = Modifier
                            .testTag("epg_mode_single_button")
                            .clickable { displayMode = EpgDisplayMode.SINGLE_CHANNEL }
                    ) {
                        Text(
                            text = if (isEnglish) "📋 List" else "📋 Liste",
                            color = if (displayMode == EpgDisplayMode.SINGLE_CHANNEL) ElectricBlue else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }

                    // Strict 100% Verified Filter Toggle
                    Surface(
                        color = if (showOnlyVerified) Color(0xFF10B981).copy(alpha = 0.18f) else NavyDeep,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, if (showOnlyVerified) Color(0xFF10B981) else GlassBorder),
                        modifier = Modifier
                            .testTag("epg_filter_verified_button")
                            .clickable { showOnlyVerified = !showOnlyVerified }
                    ) {
                        Text(
                            text = if (showOnlyVerified) {
                                if (isEnglish) "✓ 100% Matched Only" else "✓ Nur 100% Eindeutig"
                            } else {
                                if (isEnglish) "All Channels" else "Alle Sender"
                            },
                            color = if (showOnlyVerified) Color(0xFF10B981) else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                        )
                    }

                    // Compact Search Input
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(30.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NavyDeep)
                            .border(1.dp, GlassBorder, RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Suche",
                                tint = TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                            Box(modifier = Modifier.weight(1f)) {
                                if (searchQuery.isEmpty()) {
                                    Text(
                                        text = if (isEnglish) "Channel / Show..." else "Sender / Sendung...",
                                        color = TextMuted,
                                        fontSize = 11.sp,
                                        maxLines = 1
                                    )
                                }
                                BasicTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    singleLine = true,
                                    textStyle = TextStyle(color = TextPrimary, fontSize = 11.sp),
                                    cursorBrush = SolidColor(ElectricBlue),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("epg_search_input")
                                )
                            }
                            if (searchQuery.isNotEmpty()) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Löschen",
                                    tint = TextSecondary,
                                    modifier = Modifier
                                        .size(13.dp)
                                        .clickable { searchQuery = "" }
                                )
                            }
                        }
                    }
                }

                // Sync progress banner if currently syncing
                if (syncState is EpgSyncState.Syncing) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        LinearProgressIndicator(
                            progress = { (syncState.progressPercent / 100f).coerceIn(0.05f, 1f) },
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = ElectricBlue,
                            trackColor = NavyDeep
                        )
                        Text(
                            text = syncState.message,
                            color = ElectricBlue,
                            fontSize = 10.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Main Body: Either 2D EPG Grid or Single-Channel Schedule View
        if (filteredChannels.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(12.dp))
                    .background(SurfaceCard)
                    .border(1.dp, GlassBorder, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    if (syncState is EpgSyncState.Syncing) {
                        CircularProgressIndicator(color = ElectricBlue)
                        Text(
                            text = syncState.message,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    } else {
                        Text(
                            text = if (showOnlyVerified && epgGridMap.isEmpty()) {
                                if (isEnglish) "EPG database is empty or not synced yet."
                                else "Noch keine verifizierten EPG-Programmdaten geladen."
                            } else {
                                if (isEnglish) "No matching channels with 100% verified EPG found."
                                else "Keine Sender mit 100% eindeutiger EPG-Zuordnung für diesen Filter gefunden."
                            },
                            color = TextSecondary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onSyncEpg,
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                            ) {
                                Text(
                                    text = if (isEnglish) "🔄 Activate & Sync EPG Now" else "🔄 EPG jetzt aktivieren & synchronisieren",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            if (showOnlyVerified && channels.isNotEmpty()) {
                                OutlinedButton(
                                    onClick = { showOnlyVerified = false },
                                    border = BorderStroke(1.dp, GlassBorder)
                                ) {
                                    Text(
                                        text = if (isEnglish) "Show All Channels" else "Alle Sender einblenden",
                                        color = TextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else if (displayMode == EpgDisplayMode.GRID) {
            // =========================================================================
            // 2D EPG PROGRAM GRID (Sticky Channel Column + Synchronized Timeline Rows)
            // =========================================================================
            Surface(
                color = SurfaceCard,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, GlassBorder),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // 1. Sticky Top Timeline Header Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .background(NavyDeep)
                    ) {
                        // Top-left corner header
                        Box(
                            modifier = Modifier
                                .width(channelColumnWidthDp)
                                .fillMaxHeight()
                                .background(NavyDeep)
                                .padding(horizontal = 10.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Text(
                                text = if (isEnglish) "CHANNEL (${filteredChannels.size})" else "SENDER (${filteredChannels.size})",
                                color = ElectricBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        // Vertical divider
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .fillMaxHeight()
                                .background(GlassBorder)
                        )

                        // Scrollable 30-min time slot headers
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .horizontalScroll(horizontalScrollState)
                        ) {
                            Row(modifier = Modifier.width(totalTimelineWidthDp).fillMaxHeight()) {
                                for (slotIndex in 0 until totalSlots) {
                                    val slotTimeMs = gridStartMs + (slotIndex * halfHourMs)
                                    val isCurrentSlot = effectiveNowMs in slotTimeMs until (slotTimeMs + halfHourMs)
                                    val timeLabel = formatEpgTime(slotTimeMs, epgTimezone)

                                    Box(
                                        modifier = Modifier
                                            .width(slotWidthDp)
                                            .fillMaxHeight()
                                            .background(
                                                if (isCurrentSlot) ElectricBlue.copy(alpha = 0.16f)
                                                else Color.Transparent
                                            )
                                            .border(
                                                width = 0.5.dp,
                                                color = GlassBorder.copy(alpha = 0.5f)
                                            )
                                            .padding(horizontal = 8.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            if (isCurrentSlot) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(6.dp)
                                                        .clip(CircleShape)
                                                        .background(Color(0xFFEF4444))
                                                )
                                            }
                                            Text(
                                                text = timeLabel,
                                                color = if (isCurrentSlot) ElectricBlue else TextSecondary,
                                                fontSize = 12.sp,
                                                fontWeight = if (isCurrentSlot) FontWeight.ExtraBold else FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }

                            // Red "NOW" marker tick in header
                            if (effectiveNowMs in gridStartMs..gridEndMs) {
                                val nowOffsetDp = (((effectiveNowMs - gridStartMs) / 60_000f) * dpPerMinute).dp
                                Box(
                                    modifier = Modifier
                                        .offset(x = nowOffsetDp)
                                        .width(2.dp)
                                        .fillMaxHeight()
                                        .background(Color(0xFFEF4444))
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = GlassBorder, thickness = 1.dp)

                    // 2. Vertically Scrollable Channel Rows with Synchronized Horizontal Timeline
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("epg_grid_lazy_column")
                    ) {
                        items(
                            items = filteredChannels,
                            key = { it.id }
                        ) { channel ->
                            val channelPrograms = epgGridMap[channel.id].orEmpty()
                            EpgGridChannelRow(
                                channel = channel,
                                programs = channelPrograms,
                                gridStartMs = gridStartMs,
                                gridEndMs = gridEndMs,
                                effectiveNowMs = effectiveNowMs,
                                dpPerMinute = dpPerMinute,
                                totalTimelineWidthDp = totalTimelineWidthDp,
                                channelColumnWidthDp = channelColumnWidthDp,
                                rowHeightDp = rowHeightDp,
                                horizontalScrollState = horizontalScrollState,
                                epgTimezone = epgTimezone,
                                isEnglish = isEnglish,
                                onClickChannel = { onSelectChannel(channel) },
                                onClickProgram = { prog ->
                                    selectedProgramDetail = SelectedProgramDetail(channel, prog)
                                }
                            )
                            HorizontalDivider(color = GlassBorder.copy(alpha = 0.45f), thickness = 0.5.dp)
                        }
                    }
                }
            }
        } else {
            // =========================================================================
            // SINGLE-CHANNEL FULL SCHEDULE VIEW (Optional List Mode)
            // =========================================================================
            SingleChannelEpgView(
                channels = filteredChannels,
                selectedChannel = selectedSingleChannel,
                onSelectChannelForSchedule = { selectedSingleChannel = it },
                onPlayChannel = onSelectChannel,
                epgGridMap = epgGridMap,
                loadChannelSchedule = loadChannelSchedule,
                effectiveNowMs = effectiveNowMs,
                epgTimezone = epgTimezone,
                isPortrait = isPortrait,
                isEnglish = isEnglish
            )
        }
    }

    // Program Details & Play Dialog when clicking any cell in the EPG Grid
    selectedProgramDetail?.let { detail ->
        EpgProgramDetailDialog(
            channel = detail.channel,
            program = detail.program,
            effectiveNowMs = effectiveNowMs,
            epgTimezone = epgTimezone,
            isEnglish = isEnglish,
            onDismiss = { selectedProgramDetail = null },
            onWatchChannel = {
                selectedProgramDetail = null
                onSelectChannel(detail.channel)
            }
        )
    }
}

@Composable
private fun EpgGridChannelRow(
    channel: ChannelItem,
    programs: List<EpgProgram>,
    gridStartMs: Long,
    gridEndMs: Long,
    effectiveNowMs: Long,
    dpPerMinute: Float,
    totalTimelineWidthDp: Dp,
    channelColumnWidthDp: Dp,
    rowHeightDp: Dp,
    horizontalScrollState: androidx.compose.foundation.ScrollState,
    epgTimezone: String,
    isEnglish: Boolean,
    onClickChannel: () -> Unit,
    onClickProgram: (EpgProgram) -> Unit
) {
    val visiblePrograms = remember(programs, gridStartMs, gridEndMs) {
        programs
            .filter { it.endTime > gridStartMs && it.startTime < gridEndMs }
            .sortedBy { it.startTime }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(rowHeightDp)
            .background(SurfaceCard)
    ) {
        // Sticky Left Channel Info Cell
        Row(
            modifier = Modifier
                .width(channelColumnWidthDp)
                .fillMaxHeight()
                .background(NavyDark.copy(alpha = 0.92f))
                .clickable { onClickChannel() }
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NavyDeep)
                    .border(1.dp, GlassBorder, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (!channel.logoUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = channel.logoUrl,
                        contentDescription = channel.name,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(3.dp),
                        contentScale = ContentScale.Fit
                    )
                } else {
                    Text(
                        text = channel.name.take(2).uppercase(),
                        color = ElectricBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = channel.name,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (visiblePrograms.isNotEmpty()) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "100% Verifiziert",
                            tint = Color(0xFF10B981),
                            modifier = Modifier.size(10.dp)
                        )
                        Text(
                            text = channel.epgId ?: channel.tvgId ?: "100% EPG",
                            color = Color(0xFF10B981),
                            fontSize = 9.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    } else {
                        Text(
                            text = if (isEnglish) "Unassigned" else "Nicht zugeordnet",
                            color = TextMuted,
                            fontSize = 9.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // Vertical Divider
        Box(
            modifier = Modifier
                .width(1.dp)
                .fillMaxHeight()
                .background(GlassBorder)
        )

        // Synchronized Horizontal Program Timeline Row
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .horizontalScroll(horizontalScrollState)
        ) {
            if (visiblePrograms.isEmpty()) {
                Box(
                    modifier = Modifier
                        .width(totalTimelineWidthDp)
                        .fillMaxHeight()
                        .background(NavyDeep.copy(alpha = 0.35f))
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = if (isEnglish) {
                            "No 100% unambiguous EPG mapping — hidden to prevent false program info"
                        } else {
                            "Keine 100% eindeutige EPG-Zuordnung — ausgeblendet zum Schutz vor Falschangaben"
                        },
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            } else {
                Row(
                    modifier = Modifier
                        .width(totalTimelineWidthDp)
                        .fillMaxHeight()
                ) {
                    var cursorMs = gridStartMs

                    for (prog in visiblePrograms) {
                        val clampedStart = max(prog.startTime, cursorMs)
                        val clampedEnd = min(prog.endTime, gridEndMs)
                        if (clampedEnd <= clampedStart) continue

                        // Render gap if there is blank time before this program
                        if (clampedStart > cursorMs) {
                            val gapMinutes = (clampedStart - cursorMs) / 60_000f
                            val gapWidthDp = (gapMinutes * dpPerMinute).dp
                            if (gapWidthDp > 1.dp) {
                                Box(
                                    modifier = Modifier
                                        .width(gapWidthDp)
                                        .fillMaxHeight()
                                        .background(NavyDeep.copy(alpha = 0.25f))
                                        .border(0.5.dp, GlassBorder.copy(alpha = 0.25f))
                                )
                            }
                        }

                        val durationMinutes = (clampedEnd - clampedStart) / 60_000f
                        val cellWidthDp = (durationMinutes * dpPerMinute).dp
                        val isLiveNow = effectiveNowMs in prog.startTime until prog.endTime
                        val isPast = prog.endTime <= effectiveNowMs

                        val progress = if (isLiveNow) {
                            val total = (prog.endTime - prog.startTime).coerceAtLeast(1L)
                            val elapsed = (effectiveNowMs - prog.startTime).coerceAtLeast(0L)
                            (elapsed.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                        } else 0f

                        Box(
                            modifier = Modifier
                                .width(cellWidthDp)
                                .fillMaxHeight()
                                .padding(horizontal = 1.dp, vertical = 2.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    when {
                                        isLiveNow -> Brush.horizontalGradient(
                                            listOf(
                                                ElectricBlue.copy(alpha = 0.28f),
                                                CyberCyan.copy(alpha = 0.16f)
                                            )
                                        )
                                        isPast -> Brush.horizontalGradient(
                                            listOf(
                                                NavyDeep.copy(alpha = 0.55f),
                                                NavyDeep.copy(alpha = 0.55f)
                                            )
                                        )
                                        else -> Brush.horizontalGradient(
                                            listOf(
                                                SurfaceHover.copy(alpha = 0.85f),
                                                NavyDeep.copy(alpha = 0.85f)
                                            )
                                        )
                                    }
                                )
                                .border(
                                    width = if (isLiveNow) 1.5.dp else 0.5.dp,
                                    color = if (isLiveNow) ElectricBlue else GlassBorder.copy(alpha = 0.6f),
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .clickable { onClickProgram(prog) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 6.dp, vertical = 4.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    if (isLiveNow) {
                                        Surface(
                                            color = Color(0xFFEF4444),
                                            shape = RoundedCornerShape(3.dp)
                                        ) {
                                            Text(
                                                text = "LIVE",
                                                color = Color.White,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${formatEpgTime(prog.startTime, epgTimezone)} - ${formatEpgTime(prog.endTime, epgTimezone)}",
                                        color = if (isLiveNow) ElectricBlue else TextMuted,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Clip
                                    )
                                }

                                Text(
                                    text = prog.title,
                                    color = if (isPast) TextSecondary else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (isLiveNow) FontWeight.ExtraBold else FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                if (isLiveNow) {
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(3.dp)
                                            .clip(RoundedCornerShape(2.dp)),
                                        color = ElectricBlue,
                                        trackColor = NavyDark
                                    )
                                } else {
                                    Spacer(modifier = Modifier.height(2.dp))
                                }
                            }
                        }

                        cursorMs = clampedEnd
                    }

                    // Trailing empty space if schedule ends before gridEndMs
                    if (cursorMs < gridEndMs) {
                        val remainingMinutes = (gridEndMs - cursorMs) / 60_000f
                        val remainingWidthDp = (remainingMinutes * dpPerMinute).dp
                        if (remainingWidthDp > 1.dp) {
                            Box(
                                modifier = Modifier
                                    .width(remainingWidthDp)
                                    .fillMaxHeight()
                                    .background(NavyDeep.copy(alpha = 0.2f))
                            )
                        }
                    }
                }
            }

            // Live Red Vertical "JETZT" Line across the channel row
            if (effectiveNowMs in gridStartMs..gridEndMs) {
                val nowOffsetDp = (((effectiveNowMs - gridStartMs) / 60_000f) * dpPerMinute).dp
                Box(
                    modifier = Modifier
                        .offset(x = nowOffsetDp)
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(Color(0xFFEF4444).copy(alpha = 0.85f))
                )
            }
        }
    }
}

@Composable
private fun SingleChannelEpgView(
    channels: List<ChannelItem>,
    selectedChannel: ChannelItem?,
    onSelectChannelForSchedule: (ChannelItem) -> Unit,
    onPlayChannel: (ChannelItem) -> Unit,
    epgGridMap: Map<String, List<EpgProgram>>,
    loadChannelSchedule: suspend (ChannelItem) -> List<EpgProgram>,
    effectiveNowMs: Long,
    epgTimezone: String,
    isPortrait: Boolean,
    isEnglish: Boolean
) {
    var schedule by remember { mutableStateOf<List<EpgProgram>>(emptyList()) }

    LaunchedEffect(selectedChannel, epgGridMap) {
        val ch = selectedChannel ?: return@LaunchedEffect
        val cached = epgGridMap[ch.id]
        if (!cached.isNullOrEmpty()) {
            schedule = cached
        } else {
            schedule = loadChannelSchedule(ch)
        }
    }

    Row(
        modifier = Modifier.fillMaxSize(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Left Channel Selector
        Surface(
            color = SurfaceCard,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, GlassBorder),
            modifier = Modifier
                .width(if (isPortrait) 140.dp else 240.dp)
                .fillMaxHeight()
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(6.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(channels, key = { it.id }) { ch ->
                    val isSelected = selectedChannel?.id == ch.id
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) ElectricBlue.copy(alpha = 0.2f) else Color.Transparent)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) ElectricBlue else Color.Transparent,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .clickable { onSelectChannelForSchedule(ch) }
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = ch.name,
                            color = if (isSelected) ElectricBlue else TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Right Full Schedule List
        Surface(
            color = SurfaceCard,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, GlassBorder),
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            val ch = selectedChannel
            if (ch == null) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (isEnglish) "Select a channel" else "Bitte einen Sender auswählen",
                        color = TextMuted
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = ch.name,
                                color = TextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.ExtraBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "TVG-ID: ${ch.epgId ?: ch.tvgId ?: "—"} • ${schedule.size} Sendungen",
                                color = Color(0xFF10B981),
                                fontSize = 11.sp
                            )
                        }
                        Button(
                            onClick = { onPlayChannel(ch) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isEnglish) "Watch" else "Einschalten",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = GlassBorder)
                    Spacer(modifier = Modifier.height(10.dp))

                    val upcomingAndCurrent = remember(schedule, effectiveNowMs) {
                        schedule.filter { it.endTime > effectiveNowMs }
                    }

                    if (upcomingAndCurrent.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = if (isEnglish) {
                                    "No 100% verified EPG schedule available for this channel."
                                } else {
                                    "Keine 100% eindeutig verifizierten Programmdaten für diesen Sender vorhanden."
                                },
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(upcomingAndCurrent, key = { it.id }) { prog ->
                                val isNow = effectiveNowMs in prog.startTime until prog.endTime
                                Surface(
                                    color = if (isNow) ElectricBlue.copy(alpha = 0.14f) else NavyDeep,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, if (isNow) ElectricBlue else GlassBorder)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "${formatEpgTime(prog.startTime, epgTimezone)} - ${formatEpgTime(prog.endTime, epgTimezone)} Uhr",
                                                color = if (isNow) ElectricBlue else TextSecondary,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (isNow) {
                                                Surface(
                                                    color = Color(0xFFEF4444),
                                                    shape = RoundedCornerShape(4.dp)
                                                ) {
                                                    Text(
                                                        text = "LIVE",
                                                        color = Color.White,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = prog.title,
                                            color = TextPrimary,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        if (prog.description.isNotBlank()) {
                                            Text(
                                                text = prog.description,
                                                color = TextSecondary,
                                                fontSize = 12.sp,
                                                maxLines = 3,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EpgProgramDetailDialog(
    channel: ChannelItem,
    program: EpgProgram,
    effectiveNowMs: Long,
    epgTimezone: String,
    isEnglish: Boolean,
    onDismiss: () -> Unit,
    onWatchChannel: () -> Unit
) {
    val isLiveNow = effectiveNowMs in program.startTime until program.endTime
    val durationMinutes = ((program.endTime - program.startTime) / 60_000L).coerceAtLeast(1L)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            color = SurfaceCard,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.5.dp, ElectricBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = channel.name,
                            color = ElectricBlue,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "✓ 100% Verifiziert (${program.channelTvgId})",
                            color = Color(0xFF10B981),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    if (isLiveNow) {
                        Surface(
                            color = Color(0xFFEF4444),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = if (isEnglish) "● LIVE NOW" else "● LÄUFT JETZT",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Text(
                    text = program.title,
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = NavyDeep,
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, GlassBorder)
                    ) {
                        Text(
                            text = "🕒 ${formatEpgTime(program.startTime, epgTimezone)} - ${formatEpgTime(program.endTime, epgTimezone)} Uhr ($durationMinutes Min.)",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    if (!program.category.isNullOrBlank()) {
                        Surface(
                            color = ElectricBlue.copy(alpha = 0.14f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = program.category,
                                color = ElectricBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                if (program.description.isNotBlank()) {
                    Surface(
                        color = NavyDeep,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, GlassBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = program.description,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text(
                            text = if (isEnglish) "Close" else "Schließen",
                            color = TextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onWatchChannel,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isEnglish) "Watch Channel Now" else "Sender jetzt einschalten",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
