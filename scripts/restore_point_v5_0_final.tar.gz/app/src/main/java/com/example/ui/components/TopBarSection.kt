package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import com.example.data.model.ChannelItem
import com.example.data.model.ChannelSortMode
import com.example.data.parser.ContentClassifier
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlaylistEntity
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentRose
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TopBarSection(
    playlists: List<PlaylistEntity>,
    activePlaylist: PlaylistEntity?,
    onPlaylistSelected: (String) -> Unit,
    onRefreshPlaylist: (PlaylistEntity) -> Unit,
    isRefreshing: Boolean,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    categories: List<String>,
    selectedCategory: String,
    onCategorySelected: (String) -> Unit,
    liveCount: Int,
    favoriteCount: Int = 0,
    sportCount: Int = 0,
    adultCount: Int = 0,
    internationalCount: Int = 0,
    radioCount: Int = 0,
    movieCount: Int,
    seriesCount: Int,
    channels: List<ChannelItem> = emptyList(),
    precomputedCountryFolders: List<com.example.data.parser.CountryFolder> = emptyList(),
    isEnglish: Boolean = false,
    countrySummary: com.example.data.model.CountrySummary = com.example.data.model.CountrySummary.EMPTY,
    disabledCountries: Set<String> = emptySet(),
    hiddenChannelIds: Set<String> = emptySet(),
    onToggleCountry: (String) -> Unit = {},
    onEnableAllCountries: () -> Unit = {},
    onDisableAllCountries: () -> Unit = {},
    onToggleChannelHidden: (String) -> Unit = {},
    onRemoveAllChannelsInCountry: (String) -> Unit = {},
    onRestoreAllChannelsInCountry: (String) -> Unit = {},
    onRestoreAllChannels: () -> Unit = {},
    onResetCountryAndChannelFilters: () -> Unit = {},
    onAddCustomChannel: (String, String, String, String) -> Unit = { _, _, _, _ -> },
    onOpenAddPlaylist: () -> Unit,
    onOpenAddMacPortal: () -> Unit = {},
    onOpenImportAssistant: () -> Unit = {},
    onEditPlaylistRequested: (PlaylistEntity) -> Unit = {},
    onDeletePlaylistRequested: (PlaylistEntity) -> Unit = {},
    onDeleteAllPlaylistsRequested: () -> Unit = {},
    isTvMode: Boolean = false,
    compactMode: Boolean = true,
    channelSortMode: ChannelSortMode = ChannelSortMode.DACH_CANONICAL,
    onSortModeSelected: (ChannelSortMode) -> Unit = {},
    selectedCountryCode: String = "DE",
    onSelectCountry: (String) -> Unit = {},
    showPlaylistSelector: Boolean = true,
    onOpenSettings: () -> Unit = {}
) {
    var showDeleteAllConfirmation by remember { mutableStateOf(false) }
    var isDropdownExpanded by remember { mutableStateOf(false) }
    var playlistMenuSearch by remember { mutableStateOf("") }
    var playlistForActionsDialog by remember { mutableStateOf<PlaylistEntity?>(null) }
    var isSearchExpanded by remember { mutableStateOf(searchQuery.isNotEmpty()) }
    var isHeaderMinimized by remember { mutableStateOf(false) }
    var showCountrySelectorDialog by remember { mutableStateOf(false) }
    var showSortDialog by remember { mutableStateOf(false) }

    // Rotating animation for the ring refresh symbol
    val infiniteTransition = rememberInfiniteTransition(label = "refresh_ring")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing)
        ),
        label = "rotation"
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ObsidianBlack,
                        DarkNavyCard
                    )
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        // 1. Kompakte, schlanke Kopfzeile (optimiert für Android TV & Handy)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Links: Mini-Krone + Titel + Integrierter Playlist-Wähler
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                // App Logo Icon
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .background(Color.Black)
                        .border(1.dp, GoldPrimary, RoundedCornerShape(7.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.app_logo),
                        contentDescription = "MaD Internet TV V.5.0 final",
                        modifier = Modifier.size(26.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = "MaD TV",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black,
                    color = GoldPrimary,
                    letterSpacing = 0.5.sp
                )

                if (showPlaylistSelector) {
                    Spacer(modifier = Modifier.width(8.dp))

                    // Kompakter Playlist-Wähler Chip mit vollständigem DropdownMenü
                val activeIndex = playlists.indexOfFirst { it.id == activePlaylist?.id }
                val activeNumPrefix = if (activeIndex >= 0) "#${activeIndex + 1} " else ""

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(DarkSurface)
                        .border(1.dp, BorderGlow.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .combinedClickable(
                            onClick = { isDropdownExpanded = true },
                            onLongClick = {
                                activePlaylist?.let { pl ->
                                    playlistForActionsDialog = pl
                                }
                            }
                        )
                        .focusable()
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("playlist_selector_dropdown")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tv,
                            contentDescription = "Playlist",
                            tint = GoldPrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "$activeNumPrefix${activePlaylist?.getDisplayName() ?: if (isEnglish) "Select" else "Auswählen"}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 140.dp)
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Open",
                            tint = GoldLight,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = isDropdownExpanded,
                        onDismissRequest = { isDropdownExpanded = false },
                        modifier = Modifier
                            .background(DarkNavyCard)
                            .heightIn(max = 500.dp)
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (isEnglish) "🪄 Playlist Import Assistant (.txt / Paste)" else "🪄 Playlist Import-Assistent (.txt / Paste)",
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            onClick = {
                                isDropdownExpanded = false
                                onOpenImportAssistant()
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (isEnglish) "📡 + Add MAC IPTV Portal (Stalker / MAG)" else "📡 + MAC IPTV Portal hinzufügen (00:1A:79)",
                                    color = GoldLight,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            onClick = {
                                isDropdownExpanded = false
                                onOpenAddMacPortal()
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (isEnglish) "+ Add new playlist manually (M3U / Xtream)" else "+ Playliste manuell eingeben (M3U / Xtream)",
                                    color = AccentCyan,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            onClick = {
                                isDropdownExpanded = false
                                onOpenAddPlaylist()
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (isEnglish) "🗑️ Delete all playlists" else "🗑️ Playlisten löschen (Alle)",
                                    color = AccentRose,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            onClick = {
                                isDropdownExpanded = false
                                showDeleteAllConfirmation = true
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (isEnglish) "⚙️ Settings" else "⚙️ Einstellungen",
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            },
                            onClick = {
                                isDropdownExpanded = false
                                onOpenSettings()
                            }
                        )

                        if (playlists.isNotEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .height(1.dp)
                                    .background(BorderGlow.copy(alpha = 0.3f))
                            )
                        }

                        if (playlists.size > 10) {
                            OutlinedTextField(
                                value = playlistMenuSearch,
                                onValueChange = { playlistMenuSearch = it },
                                placeholder = { Text("Playliste suchen (${playlists.size})...", fontSize = 12.sp, color = TextMuted) },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 4.dp),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = TextPrimary),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = GoldPrimary,
                                    unfocusedBorderColor = BorderGlow.copy(alpha = 0.5f),
                                    focusedContainerColor = DarkSurface,
                                    unfocusedContainerColor = DarkSurface
                                )
                            )
                        }

                        val filteredMenuPlaylists = if (playlistMenuSearch.isBlank()) playlists else playlists.filter {
                            it.getDisplayName().contains(playlistMenuSearch, ignoreCase = true)
                        }

                        filteredMenuPlaylists.forEach { pl ->
                            val origIndex = playlists.indexOf(pl)
                            val number = if (origIndex >= 0) origIndex + 1 else 1
                            DropdownMenuItem(
                                text = {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 2.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(4.dp))
                                                    .background(if (pl.id == activePlaylist?.id) GoldPrimary else DarkSurfaceElevated)
                                                    .padding(horizontal = 5.dp, vertical = 1.dp)
                                            ) {
                                                Text(
                                                    text = "#$number",
                                                    color = if (pl.id == activePlaylist?.id) ObsidianBlack else GoldLight,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 10.sp
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = pl.getDisplayName(),
                                                color = if (pl.id == activePlaylist?.id) GoldPrimary else TextPrimary,
                                                fontWeight = if (pl.id == activePlaylist?.id) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                modifier = Modifier.weight(1f, fill = false)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "(${pl.type.name})",
                                                fontSize = 10.sp,
                                                color = TextMuted
                                            )
                                        }
                                    }
                                },
                                trailingIcon = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = {
                                                isDropdownExpanded = false
                                                onEditPlaylistRequested(pl)
                                            },
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Edit,
                                                contentDescription = "Edit Playlist with PIN",
                                                tint = GoldLight,
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(2.dp))
                                        IconButton(
                                            onClick = {
                                                isDropdownExpanded = false
                                                playlistForActionsDialog = pl
                                            },
                                            modifier = Modifier.size(26.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Löschen / Optionen",
                                                tint = com.example.ui.theme.AccentRose.copy(alpha = 0.85f),
                                                modifier = Modifier.size(15.dp)
                                            )
                                        }
                                    }
                                },
                                onClick = {
                                    onPlaylistSelected(pl.id)
                                    isDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
                }

            // Rechts: Live TV Badge + Suche-Knopf + Refresh-Knopf + Minimieren
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Live TV Quick Badge
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DarkSurfaceElevated.copy(alpha = 0.9f),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, BorderGlow.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(AccentEmerald)
                        )
                        Text(
                            text = "$liveCount",
                            fontWeight = FontWeight.Bold,
                            color = AccentEmerald,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "TV",
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }
                }

                // Suche Umschalten
                IconButton(
                    onClick = {
                        isSearchExpanded = !isSearchExpanded
                        if (!isSearchExpanded && searchQuery.isNotEmpty()) {
                            onSearchQueryChange("")
                        }
                    },
                    modifier = Modifier
                        .size(30.dp)
                        .focusable()
                        .testTag("toggle_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Suche",
                        tint = if (isSearchExpanded || searchQuery.isNotEmpty()) GoldPrimary else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Playlist Aktualisieren Button
                IconButton(
                    onClick = { activePlaylist?.let { onRefreshPlaylist(it) } },
                    enabled = !isRefreshing && activePlaylist != null,
                    modifier = Modifier
                        .size(30.dp)
                        .focusable()
                        .testTag("playlist_refresh_ring_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Aktualisieren",
                        tint = if (isRefreshing) GoldLight else GoldPrimary,
                        modifier = Modifier
                            .size(18.dp)
                            .rotate(if (isRefreshing) rotation else 0f)
                    )
                }

                // Einstellungen Button
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(30.dp)
                        .focusable()
                        .testTag("topbar_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = if (isEnglish) "Settings" else "Einstellungen",
                        tint = GoldPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Kopfzeile Minimieren / Erweitern
                IconButton(
                    onClick = { isHeaderMinimized = !isHeaderMinimized },
                    modifier = Modifier
                        .size(30.dp)
                        .focusable()
                        .testTag("toggle_minimize_header")
                ) {
                    Icon(
                        imageVector = if (isHeaderMinimized) Icons.Default.KeyboardArrowDown else Icons.Default.KeyboardArrowUp,
                        contentDescription = if (isHeaderMinimized) "Kopfzeile erweitern" else "Kopfzeile minimieren",
                        tint = if (isHeaderMinimized) GoldPrimary else TextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 2. Darunter: Suchfeld (nur sichtbar wenn Suche geöffnet oder Text vorhanden ist)
        if (isSearchExpanded || searchQuery.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_input_field"),
                placeholder = {
                    Text(
                        text = if (isEnglish) "Search channels, movies, series..." else "TV Sender, Filme oder Serien suchen...",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = GoldPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear",
                                tint = TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    } else {
                        IconButton(onClick = { isSearchExpanded = false }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = TextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = BorderGlow.copy(alpha = 0.4f),
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 4. Hierarchical Country & Favorites Bar:
        // Prioritized order: Favoriten, Alle, DE, AT, CH, etc. Countries with selector disabled are hidden from quick bar.
        val countryFolders = remember(precomputedCountryFolders, disabledCountries) {
            if (disabledCountries.isEmpty()) {
                precomputedCountryFolders
            } else {
                precomputedCountryFolders.filter { it.code.uppercase() !in disabledCountries }
            }
        }

        // Active country code deduced from selectedCategory
        val activeCountryCode = remember(selectedCategory, countryFolders) {
            when {
                selectedCategory.equals("FAVORITEN", ignoreCase = true) || selectedCategory.equals("FAVORITES", ignoreCase = true) -> null
                selectedCategory.equals("ALLE", ignoreCase = true) || selectedCategory.isBlank() -> null
                countryFolders.any { it.code.equals(selectedCategory, ignoreCase = true) } -> selectedCategory.uppercase()
                else -> {
                    // Check which country folder owns this subfolder
                    val found = countryFolders.firstOrNull { folder ->
                        folder.subFolders.any { it.equals(selectedCategory, ignoreCase = true) }
                    }
                    found?.code ?: com.example.data.parser.ContentClassifier.detectCountryForGroup(selectedCategory)
                }
            }
        }

        // 4. Hierarchical Category, Favorites & Sort Bar (ausblendbar über Pfeil-Symbol oben):
        if (!isHeaderMinimized) {
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
            // 0a. Länder-Manager / Länderauswahl Button
            item {
                val hasDisabled = disabledCountries.isNotEmpty()
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (hasDisabled) GoldPrimary.copy(alpha = 0.25f) else DarkSurface)
                        .border(
                            width = 1.2.dp,
                            color = if (hasDisabled) GoldPrimary else BorderGlow.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { showCountrySelectorDialog = true }
                        .padding(horizontal = 11.dp, vertical = 6.dp)
                        .testTag("open_country_manager_chip")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🌐 ", fontSize = 12.sp)
                        Text(
                            text = if (isEnglish) "Countries" else "Länder",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (hasDisabled) GoldLight else Color.White
                        )
                        if (disabledCountries.isNotEmpty()) {
                            Text(
                                text = " (${ContentClassifier.ALL_KNOWN_COUNTRIES.size - disabledCountries.size})",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = GoldLight
                            )
                        }
                    }
                }
            }

            // 0b. Sortierung Button
            item {
                val isCustomSort = channelSortMode != ChannelSortMode.DACH_CANONICAL
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isCustomSort) GoldPrimary.copy(alpha = 0.22f) else DarkSurface)
                        .border(
                            width = 1.2.dp,
                            color = if (isCustomSort) GoldPrimary else BorderSubtle,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { showSortDialog = true }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("open_channel_sort_chip")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = "Sortierung öffnen",
                            tint = if (isCustomSort) GoldLight else Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isEnglish) channelSortMode.titleEn else channelSortMode.titleDe,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCustomSort) GoldLight else Color.White
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = if (isCustomSort) GoldPrimary else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            // 1. Favoriten
            item {
                val isFavSelected = selectedCategory.equals("FAVORITEN", ignoreCase = true) || selectedCategory.equals("FAVORITES", ignoreCase = true)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isFavSelected) com.example.ui.theme.AccentRose else com.example.ui.theme.AccentRose.copy(alpha = 0.18f))
                        .border(
                            width = 1.dp,
                            color = if (isFavSelected) com.example.ui.theme.AccentRose else com.example.ui.theme.AccentRose.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { onCategorySelected("FAVORITEN") }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("filter_chip_favoriten")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "❤️ ", fontSize = 11.sp)
                        Text(
                            text = if (isEnglish) "Favorites" else "Favoriten",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isFavSelected) Color.Black else com.example.ui.theme.AccentRose
                        )
                        if (favoriteCount > 0) {
                            Text(
                                text = " ($favoriteCount)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isFavSelected) Color.Black.copy(alpha = 0.8f) else TextMuted
                            )
                        }
                    }
                }
            }

            // 2. Alle Sender
            item {
                val isAlleSelected = (selectedCategory.equals("ALLE", ignoreCase = true) || selectedCategory.isBlank()) && activeCountryCode == null
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isAlleSelected) GoldPrimary else DarkSurface)
                        .border(
                            width = 1.dp,
                            color = if (isAlleSelected) GoldPrimary else BorderGlow.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { onCategorySelected("ALLE") }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("filter_chip_alle")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "📺 ", fontSize = 11.sp)
                        Text(
                            text = if (isEnglish) "All" else "Alle",
                            fontSize = 12.sp,
                            fontWeight = if (isAlleSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isAlleSelected) Color.Black else TextSecondary
                        )
                        if (liveCount > 0) {
                            Text(
                                text = " ($liveCount)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isAlleSelected) Color.Black.copy(alpha = 0.8f) else TextMuted
                            )
                        }
                    }
                }
            }

            // 3. Deduplicated Countries: Each country listed EXACTLY ONCE
            items(countryFolders) { folder ->
                val isCurrentCountryActive = activeCountryCode.equals(folder.code, ignoreCase = true)
                val isDirectSelected = selectedCategory.equals(folder.code, ignoreCase = true)
                val isDach = folder.code in listOf("DE", "AT", "CH")
                val isSport = folder.code == "SPORT"
                val isAdult = folder.code == "ADULT"

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            when {
                                isDirectSelected -> GoldPrimary
                                isCurrentCountryActive && isDach -> GoldPrimary.copy(alpha = 0.35f)
                                isCurrentCountryActive -> AccentCyan.copy(alpha = 0.35f)
                                isDach -> GoldPrimary.copy(alpha = 0.15f)
                                isSport -> AccentEmerald.copy(alpha = 0.15f)
                                isAdult -> com.example.ui.theme.AccentRose.copy(alpha = 0.15f)
                                else -> DarkSurface
                            }
                        )
                        .border(
                            width = if (isDirectSelected || isCurrentCountryActive) 1.5.dp else 1.dp,
                            color = when {
                                isDirectSelected -> GoldPrimary
                                isCurrentCountryActive && isDach -> GoldPrimary
                                isCurrentCountryActive -> AccentCyan
                                isDach -> GoldPrimary.copy(alpha = 0.5f)
                                isSport -> AccentEmerald.copy(alpha = 0.5f)
                                isAdult -> com.example.ui.theme.AccentRose.copy(alpha = 0.5f)
                                else -> BorderGlow.copy(alpha = 0.2f)
                            },
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { onCategorySelected(folder.code) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("filter_chip_country_${folder.code.lowercase()}")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "${folder.flagEmoji} ", fontSize = 11.sp)
                        Text(
                            text = folder.displayName,
                            fontSize = 12.sp,
                            fontWeight = if (isDirectSelected || isCurrentCountryActive || isDach) FontWeight.Bold else FontWeight.Medium,
                            color = when {
                                isDirectSelected -> Color.Black
                                isCurrentCountryActive && isDach -> GoldLight
                                isCurrentCountryActive -> AccentCyan
                                isDach -> GoldLight
                                isSport -> AccentEmerald
                                isAdult -> com.example.ui.theme.AccentRose
                                else -> TextSecondary
                            }
                        )
                        // Channel count badge on folder
                        if (folder.channelCount > 0) {
                            Text(
                                text = " (${folder.channelCount})",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDirectSelected) Color.Black.copy(alpha = 0.8f) else TextMuted
                            )
                        } else if (folder.subFolders.isNotEmpty()) {
                            Text(
                                text = " • ${folder.subFolders.size}",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isDirectSelected) Color.Black.copy(alpha = 0.8f) else TextMuted
                            )
                        }
                    }
                }
            }
        }

        // 5. Hierarchical Sub-Folder Bar (Unterordner):
        // Automatically reveals the sub-folders for the active country or DE quick-access folders when on Alle.
        val displayedFolder = if (activeCountryCode != null) {
            countryFolders.firstOrNull { it.code.equals(activeCountryCode, ignoreCase = true) }
        } else {
            // When on "Alle", provide instant 1-tap access to DE & AT prioritized folders (EU Austria, 24/7, Allgemeines, etc.)
            countryFolders.firstOrNull { it.code == "DE" }
        }

        if (displayedFolder != null && displayedFolder.subFolders.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // First pill: All channels of this country
                item {
                    val isAllOfCountrySelected = selectedCategory.equals(displayedFolder.code, ignoreCase = true)
                    val countBadge = if (displayedFolder.channelCount > 0) " (${displayedFolder.channelCount})" else ""
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isAllOfCountrySelected) GoldPrimary else DarkSurfaceElevated)
                            .border(
                                width = 1.dp,
                                color = if (isAllOfCountrySelected) GoldPrimary else BorderGlow.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onCategorySelected(displayedFolder.code) }
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                            .testTag("sub_folder_all_${displayedFolder.code.lowercase()}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "📁 Alle ${displayedFolder.displayName}$countBadge",
                                fontSize = 11.sp,
                                fontWeight = if (isAllOfCountrySelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isAllOfCountrySelected) Color.Black else TextPrimary
                            )
                        }
                    }
                }

                // Sub-folder pills (e.g. EU DE Allgemeines, EU DE 24/7, EU DE Dokumentar, EU Austria, etc.)
                items(displayedFolder.subFolders) { subFolder ->
                    val isSubSelected = selectedCategory.equals(subFolder, ignoreCase = true)
                    val cleanName = com.example.data.parser.ContentClassifier.getCleanSubFolderName(subFolder)
                    val subCount = displayedFolder.subFolderCounts[subFolder] ?: 0
                    val countBadge = if (subCount > 0) " ($subCount)" else ""

                    // Sub-folder icon based on content topic
                    val subIcon = when {
                        cleanName.contains("Allgemein", ignoreCase = true) || cleanName.contains("Free", ignoreCase = true) -> "📺"
                        cleanName.contains("24/7", ignoreCase = true) || cleanName.contains("247", ignoreCase = true) -> "⏱️"
                        cleanName.contains("Doku", ignoreCase = true) || cleanName.contains("Wissen", ignoreCase = true) -> "📚"
                        cleanName.contains("Cinema", ignoreCase = true) || cleanName.contains("Film", ignoreCase = true) || cleanName.contains("Kino", ignoreCase = true) -> "🎬"
                        cleanName.contains("Sky", ignoreCase = true) -> "⭐"
                        cleanName.contains("Serie", ignoreCase = true) -> "🍿"
                        cleanName.contains("Sport", ignoreCase = true) || cleanName.contains("Fussball", ignoreCase = true) || cleanName.contains("Bundesliga", ignoreCase = true) -> "⚽"
                        cleanName.contains("Kids", ignoreCase = true) || cleanName.contains("Kinder", ignoreCase = true) -> "🧸"
                        cleanName.contains("Musik", ignoreCase = true) || cleanName.contains("Music", ignoreCase = true) -> "🎵"
                        cleanName.contains("News", ignoreCase = true) || cleanName.contains("Nachrichten", ignoreCase = true) -> "📰"
                        cleanName.contains("Austria", ignoreCase = true) || cleanName.contains("Österreich", ignoreCase = true) -> "🇦🇹"
                        cleanName.contains("Schweiz", ignoreCase = true) || cleanName.contains("Swiss", ignoreCase = true) -> "🇨🇭"
                        cleanName.contains("Adult", ignoreCase = true) || cleanName.contains("XXX", ignoreCase = true) -> "🔞"
                        else -> "📁"
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                when {
                                    isSubSelected -> AccentCyan
                                    cleanName in listOf("Allgemeines", "24/7", "Dokumentar", "Austria") -> DarkSurfaceElevated
                                    else -> DarkSurfaceElevated
                                }
                            )
                            .border(
                                width = 1.dp,
                                color = when {
                                    isSubSelected -> AccentCyan
                                    cleanName in listOf("Allgemeines", "24/7", "Dokumentar", "Austria") -> GoldPrimary.copy(alpha = 0.4f)
                                    else -> BorderGlow.copy(alpha = 0.3f)
                                },
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onCategorySelected(subFolder) }
                            .padding(horizontal = 9.dp, vertical = 4.dp)
                            .testTag("sub_folder_${cleanName.lowercase().replace(" ", "_")}")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "$subIcon $cleanName$countBadge",
                                fontSize = 11.sp,
                                fontWeight = if (isSubSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSubSelected) Color.Black else (if (cleanName in listOf("Allgemeines", "24/7", "Dokumentar", "Austria")) GoldLight else TextPrimary)
                            )
                        }
                    }
                }
            }
        }
    }
    }

    // Playlist Actions Dialog (Long-press & options: Delete without PIN, Edit with PIN, Refresh, Select)
    if (playlistForActionsDialog != null) {
        PlaylistActionsDialog(
            playlist = playlistForActionsDialog!!,
            isActive = playlistForActionsDialog?.id == activePlaylist?.id,
            onDismiss = { playlistForActionsDialog = null },
            onDeletePlaylist = { pl ->
                playlistForActionsDialog = null
                onDeletePlaylistRequested(pl)
            },
            onEditPlaylist = { pl ->
                playlistForActionsDialog = null
                onEditPlaylistRequested(pl)
            },
            onRefreshPlaylist = { pl ->
                playlistForActionsDialog = null
                onRefreshPlaylist(pl)
            },
            onSelectPlaylist = { id ->
                playlistForActionsDialog = null
                onPlaylistSelected(id)
            },
            isEnglish = isEnglish
        )
    }

    if (showDeleteAllConfirmation) {
        AlertDialog(
            onDismissRequest = { showDeleteAllConfirmation = false },
            containerColor = DarkNavyCard,
            titleContentColor = TextPrimary,
            textContentColor = TextSecondary,
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteForever,
                            contentDescription = null,
                            tint = AccentRose,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isEnglish) "Delete All Playlists?" else "Alle Playlisten löschen?",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = AccentRose
                        )
                    }
                    IconButton(
                        onClick = { showDeleteAllConfirmation = false },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = if (isEnglish) "Close" else "Schließen",
                            tint = TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            },
            text = {
                Text(
                    text = if (isEnglish)
                        "Are you sure you want to permanently delete ALL playlists and channels from the local database? This cannot be undone."
                    else
                        "Möchtest du wirklich ALLE Playlisten und Sender vollständig aus der Datenbank löschen? Die Playlistenliste wird komplett geleert.",
                    fontSize = 14.sp,
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteAllConfirmation = false
                        onDeleteAllPlaylistsRequested()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentRose),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isEnglish) "Yes, Delete All" else "Ja, alle löschen",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteAllConfirmation = false },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (isEnglish) "Cancel" else "Abbrechen",
                        color = TextSecondary
                    )
                }
            }
        )
    }

    if (showCountrySelectorDialog) {
        CountrySelectorDialog(
            allChannels = channels,
            disabledCountries = disabledCountries,
            hiddenChannelIds = hiddenChannelIds,
            selectedCategory = selectedCategory,
            countrySummary = countrySummary,
            isTvMode = isTvMode,
            onSelectCountry = { countryCode ->
                onSelectCountry(countryCode)
                onCategorySelected(countryCode)
            },
            onToggleCountry = onToggleCountry,
            onEnableAllCountries = onEnableAllCountries,
            onDisableAllCountries = onDisableAllCountries,
            onToggleChannelHidden = onToggleChannelHidden,
            onRemoveAllChannelsInCountry = onRemoveAllChannelsInCountry,
            onRestoreAllChannelsInCountry = onRestoreAllChannelsInCountry,
            onRestoreAllChannels = onRestoreAllChannels,
            onResetAll = onResetCountryAndChannelFilters,
            onAddCustomChannel = onAddCustomChannel,
            onDismissRequest = { showCountrySelectorDialog = false }
        )
    }

    if (showSortDialog) {
        ChannelSortDialog(
            currentMode = channelSortMode,
            onModeSelected = { mode ->
                onSortModeSelected(mode)
            },
            onDismiss = { showSortDialog = false },
            isEnglish = isEnglish
        )
    }
}
