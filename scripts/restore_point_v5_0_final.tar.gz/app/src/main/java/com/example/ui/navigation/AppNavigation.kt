package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import com.example.data.model.ContentType
import com.example.data.model.PlaylistEntity
import com.example.data.model.PlaylistType
import com.example.ui.components.*
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab
import com.example.ui.viewmodel.MainViewModel

@Composable
fun AppNavigation(
    viewModel: MainViewModel = viewModel()
) {
    val configuration = LocalConfiguration.current
    val context = LocalContext.current
    val isTvOrWide = configuration.smallestScreenWidthDp >= 600

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val allChannels by viewModel.allChannels.collectAsStateWithLifecycle()
    val currentlyPlaying by viewModel.currentlyPlaying.collectAsStateWithLifecycle()
    val isPlayerFullscreen by viewModel.isPlayerFullscreen.collectAsStateWithLifecycle()
    val badgeCounts by viewModel.badgeCounts.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val activePlaylistId by viewModel.activePlaylistId.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val countryFolders by viewModel.countryFolders.collectAsStateWithLifecycle()
    val filteredLiveChannels by viewModel.filteredLiveChannels.collectAsStateWithLifecycle()
    val countrySummary by viewModel.countrySummary.collectAsStateWithLifecycle()
    val disabledCountries by viewModel.disabledCountries.collectAsStateWithLifecycle()
    val hiddenChannelIds by viewModel.hiddenChannelIds.collectAsStateWithLifecycle()
    val channelSortMode by viewModel.channelSortMode.collectAsStateWithLifecycle()
    val isRecordingNow by viewModel.isRecordingNow.collectAsStateWithLifecycle()
    val isAppUnlocked by viewModel.isAppUnlocked.collectAsStateWithLifecycle()
    val playlistUpdateNotice by viewModel.playlistUpdateNotice.collectAsStateWithLifecycle()
    val vodResumeList by viewModel.vodResumeList.collectAsStateWithLifecycle()
    val allVodHistory by viewModel.allVodHistory.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()
    val macPortalDialogState by viewModel.macPortalDialogState.collectAsStateWithLifecycle()

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            viewModel.clearStatusMessage()
        }
    }

    val isEnglish = settings.language.equals("en", ignoreCase = true)
    val activePlaylist = playlists.firstOrNull { it.id == activePlaylistId } ?: playlists.firstOrNull()

    // Dialog state management
    var showAddPlaylistDialog by remember { mutableStateOf(false) }
    var addPlaylistInitialTab by remember { mutableIntStateOf(0) }
    var playlistToUnlock by remember { mutableStateOf<PlaylistEntity?>(null) }
    var playlistToEdit by remember { mutableStateOf<PlaylistEntity?>(null) }
    var showPinPrompt by remember { mutableStateOf(false) }
    var showImportAssistantDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showVodDownloadManager by remember { mutableStateOf(false) }
    val recordings by viewModel.recordings.collectAsStateWithLifecycle()

    val isFullscreenPlaybackActive = isPlayerFullscreen && currentlyPlaying != null

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
    ) {
        if (!isFullscreenPlaybackActive) {
            if (isTvOrWide) {
            Row(modifier = Modifier.fillMaxSize()) {
                TvNavigationRail(
                    selectedTab = selectedTab,
                    onTabSelected = { viewModel.selectTab(it) },
                    liveCount = badgeCounts.liveCount,
                    radioCount = badgeCounts.radioCount,
                    movieCount = badgeCounts.movieCount,
                    seriesCount = badgeCounts.seriesCount,
                    isEnglish = isEnglish
                )

                Column(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    TopBarSection(
                        playlists = playlists,
                        activePlaylist = activePlaylist,
                        onPlaylistSelected = { viewModel.switchPlaylist(it) },
                        onRefreshPlaylist = { viewModel.refreshPlaylist(it) },
                        isRefreshing = isRefreshing,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        categories = categories,
                        selectedCategory = selectedCategory,
                        onCategorySelected = { viewModel.setSelectedCategory(it) },
                        liveCount = badgeCounts.liveCount,
                        favoriteCount = badgeCounts.favoriteCount,
                        sportCount = badgeCounts.sportCount,
                        adultCount = badgeCounts.adultCount,
                        internationalCount = badgeCounts.internationalCount,
                        radioCount = badgeCounts.radioCount,
                        movieCount = badgeCounts.movieCount,
                        seriesCount = badgeCounts.seriesCount,
                        channels = allChannels,
                        precomputedCountryFolders = countryFolders,
                        isEnglish = isEnglish,
                        countrySummary = countrySummary,
                        disabledCountries = disabledCountries,
                        hiddenChannelIds = hiddenChannelIds,
                        onToggleCountry = { viewModel.toggleCountry(it) },
                        onToggleChannelHidden = { viewModel.toggleChannelHidden(it) },
                        onOpenAddPlaylist = {
                            addPlaylistInitialTab = 0
                            showAddPlaylistDialog = true
                        },
                        onOpenAddMacPortal = {
                            addPlaylistInitialTab = 2
                            showAddPlaylistDialog = true
                        },
                        onOpenImportAssistant = { showImportAssistantDialog = true },
                        onEditPlaylistRequested = {
                            playlistToUnlock = it
                            showPinPrompt = true
                        },
                        onDeletePlaylistRequested = { viewModel.deletePlaylist(it) },
                        onDeleteAllPlaylistsRequested = { viewModel.deleteAllPlaylists() },
                        isTvMode = true,
                        compactMode = true,
                        channelSortMode = channelSortMode,
                        onSortModeSelected = { viewModel.setChannelSortMode(it) },
                        onEnableAllCountries = { viewModel.enableAllCountries() },
                        onDisableAllCountries = { viewModel.disableAllCountries() },
                        onRemoveAllChannelsInCountry = { viewModel.removeAllChannelsInCountry(it) },
                        onRestoreAllChannelsInCountry = { viewModel.restoreAllChannelsInCountry(it) },
                        onRestoreAllChannels = { viewModel.restoreAllChannels() },
                        onResetCountryAndChannelFilters = { viewModel.resetCountryAndChannelFilters() },
                        onAddCustomChannel = { name, url, code, group -> viewModel.addCustomChannel(name, url, code, group) },
                        showPlaylistSelector = true,
                        onOpenSettings = { viewModel.selectTab(MainTab.SETTINGS) }
                    )

                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            if (playlistUpdateNotice.isVisible) {
                                PlaylistUpdateBanner(
                                    notice = playlistUpdateNotice,
                                    onDismiss = { viewModel.dismissPlaylistUpdateNotice() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                )
                            }
                            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                MainScreenContent(
                                    viewModel = viewModel,
                                    selectedTab = selectedTab,
                                    isEnglish = isEnglish,
                                    onOpenAddPlaylist = {
                                        addPlaylistInitialTab = 0
                                        showAddPlaylistDialog = true
                                    },
                                    onOpenAddMacPortal = {
                                        addPlaylistInitialTab = 2
                                        showAddPlaylistDialog = true
                                    },
                                    onOpenImportAssistant = { showImportAssistantDialog = true },
                                    onEditPlaylist = {
                                        playlistToUnlock = it
                                        showPinPrompt = true
                                    },
                                    onOpenBackupDialog = { showBackupDialog = true },
                                    onOpenRestoreDialog = { showRestoreDialog = true },
                                    onOpenDownloadManager = { showVodDownloadManager = true }
                                )
                            }
                        }
                    }
                }
            }
        } else {
            Scaffold(
                containerColor = DarkNavyBackground,
                contentWindowInsets = WindowInsets(0, 0, 0, 0),
                topBar = {
                    TopBarSection(
                        playlists = playlists,
                        activePlaylist = activePlaylist,
                        onPlaylistSelected = { viewModel.switchPlaylist(it) },
                        onRefreshPlaylist = { viewModel.refreshPlaylist(it) },
                        isRefreshing = isRefreshing,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { viewModel.setSearchQuery(it) },
                        categories = categories,
                        selectedCategory = selectedCategory,
                        onCategorySelected = { viewModel.setSelectedCategory(it) },
                        liveCount = badgeCounts.liveCount,
                        favoriteCount = badgeCounts.favoriteCount,
                        sportCount = badgeCounts.sportCount,
                        adultCount = badgeCounts.adultCount,
                        internationalCount = badgeCounts.internationalCount,
                        radioCount = badgeCounts.radioCount,
                        movieCount = badgeCounts.movieCount,
                        seriesCount = badgeCounts.seriesCount,
                        channels = allChannels,
                        precomputedCountryFolders = countryFolders,
                        isEnglish = isEnglish,
                        countrySummary = countrySummary,
                        disabledCountries = disabledCountries,
                        hiddenChannelIds = hiddenChannelIds,
                        onToggleCountry = { viewModel.toggleCountry(it) },
                        onToggleChannelHidden = { viewModel.toggleChannelHidden(it) },
                        onOpenAddPlaylist = {
                            addPlaylistInitialTab = 0
                            showAddPlaylistDialog = true
                        },
                        onOpenAddMacPortal = {
                            addPlaylistInitialTab = 2
                            showAddPlaylistDialog = true
                        },
                        onOpenImportAssistant = { showImportAssistantDialog = true },
                        onEditPlaylistRequested = {
                            playlistToUnlock = it
                            showPinPrompt = true
                        },
                        onDeletePlaylistRequested = { viewModel.deletePlaylist(it) },
                        onDeleteAllPlaylistsRequested = { viewModel.deleteAllPlaylists() },
                        isTvMode = false,
                        compactMode = true,
                        channelSortMode = channelSortMode,
                        onSortModeSelected = { viewModel.setChannelSortMode(it) },
                        onEnableAllCountries = { viewModel.enableAllCountries() },
                        onDisableAllCountries = { viewModel.disableAllCountries() },
                        onRemoveAllChannelsInCountry = { viewModel.removeAllChannelsInCountry(it) },
                        onRestoreAllChannelsInCountry = { viewModel.restoreAllChannelsInCountry(it) },
                        onRestoreAllChannels = { viewModel.restoreAllChannels() },
                        onResetCountryAndChannelFilters = { viewModel.resetCountryAndChannelFilters() },
                        onAddCustomChannel = { name, url, code, group -> viewModel.addCustomChannel(name, url, code, group) },
                        showPlaylistSelector = true, // Shows playlist selector chip next to MaD TV below status bar
                        onOpenSettings = { viewModel.selectTab(MainTab.SETTINGS) }
                    )
                },
                bottomBar = {
                    BottomNavigationSection(
                        selectedTab = selectedTab,
                        onTabSelected = { viewModel.selectTab(it) },
                        liveCount = badgeCounts.liveCount,
                        radioCount = badgeCounts.radioCount,
                        movieCount = badgeCounts.movieCount,
                        seriesCount = badgeCounts.seriesCount,
                        isEnglish = isEnglish
                    )
                }
            ) { padding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        if (playlistUpdateNotice.isVisible) {
                            PlaylistUpdateBanner(
                                notice = playlistUpdateNotice,
                                onDismiss = { viewModel.dismissPlaylistUpdateNotice() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                            MainScreenContent(
                                viewModel = viewModel,
                                selectedTab = selectedTab,
                                isEnglish = isEnglish,
                                onOpenAddPlaylist = {
                                    addPlaylistInitialTab = 0
                                    showAddPlaylistDialog = true
                                },
                                onOpenAddMacPortal = {
                                    addPlaylistInitialTab = 2
                                    showAddPlaylistDialog = true
                                },
                                onOpenImportAssistant = { showImportAssistantDialog = true },
                                onEditPlaylist = {
                                    playlistToUnlock = it
                                    showPinPrompt = true
                                },
                                onOpenBackupDialog = { showBackupDialog = true },
                                onOpenRestoreDialog = { showRestoreDialog = true },
                                onOpenDownloadManager = { showVodDownloadManager = true }
                            )
                        }
                    }
                }
            }
            }
        }

        // Fullscreen Video Player overlay when a channel is actively playing
        if (isFullscreenPlaybackActive) {
            val channel = currentlyPlaying!!
            val playerChannelList = if (channel.playlistId == LIVE_TV_LIGHT_PLAYLIST_ID) {
                LiveTvLightCatalog.asChannelItems()
            } else {
                filteredLiveChannels.ifEmpty { allChannels }
            }
            NexusPlayerView(
                channel = channel,
                allChannels = playerChannelList,
                playerManager = viewModel.playerManager,
                settings = settings,
                isRecording = isRecordingNow,
                onToggleRecording = { viewModel.toggleLiveRecording() },
                onScheduleRecording = { startH, startM, endH, endM ->
                    viewModel.scheduleTimedRecording(channel, startH, startM, endH, endM)
                },
                onDownloadVod = { vodCh ->
                    viewModel.downloadVodContent(vodCh)
                },
                onSelectChannel = { newCh -> viewModel.playContent(newCh) },
                onClose = { viewModel.closePlayer() },
                onToggleFavorite = { viewModel.toggleFavorite(channel) },
                isEnglish = isEnglish
            )
        }

        // VOD Download & Recording Manager Dialog (Downloads/MaDIPTV)
        if (showVodDownloadManager) {
            VodDownloadManagerDialog(
                recordings = recordings,
                isEnglish = isEnglish,
                onDismiss = { showVodDownloadManager = false },
                onPlayOffline = { item -> viewModel.playRecording(item) },
                onCancelDownload = { item -> viewModel.cancelDownload(item) },
                onDeleteRecording = { item -> viewModel.deleteRecording(item) }
            )
        }

        // Add Playlist Dialog
        if (showAddPlaylistDialog) {
            AddPlaylistDialog(
                onDismiss = { showAddPlaylistDialog = false },
                onAddM3uUrl = { name, url ->
                    viewModel.addM3uUrlPlaylist(name, url)
                    showAddPlaylistDialog = false
                },
                onAddXtream = { name, url, user, pass ->
                    viewModel.addXtreamPlaylist(name, url, user, pass)
                    showAddPlaylistDialog = false
                },
                onAddMacPortal = { name, portalUrl, mac ->
                    viewModel.addMacPortalPlaylist(name, portalUrl, mac)
                    showAddPlaylistDialog = false
                },
                onAddLocalFile = { name, uri ->
                    viewModel.addLocalM3uFile(name, uri)
                    showAddPlaylistDialog = false
                },
                onAddBatchWithoutSync = { candidates ->
                    viewModel.importCandidatesBatch(candidates)
                    showAddPlaylistDialog = false
                },
                onOpenImportAssistant = {
                    showAddPlaylistDialog = false
                    showImportAssistantDialog = true
                },
                initialTypeIndex = addPlaylistInitialTab,
                isEnglish = isEnglish
            )
        }

        // MAC Portal Connection Progress & Live Channel Counter Dialog
        val currentMacState = macPortalDialogState
        if (currentMacState != null && currentMacState.isVisible) {
            MacPortalConnectionDialog(
                state = currentMacState,
                onDismiss = { viewModel.dismissMacPortalDialog() },
                onRetry = { viewModel.retryMacPortalConnection() },
                onOpenPlaylist = { playlistId ->
                    viewModel.switchPlaylist(playlistId)
                    viewModel.selectTab(MainTab.LIVE_TV)
                },
                isEnglish = isEnglish
            )
        }

        // Playlist Edit PIN Prompt Dialog
        if (showPinPrompt && playlistToUnlock != null) {
            PinPromptDialog(
                title = if (isEnglish) "PIN Verification" else "PIN-Abfrage: ${playlistToUnlock?.name}",
                subtitle = if (isEnglish) "Enter PIN to edit this playlist" else "Gib die Sicherheits-PIN ein, um die Playliste zu bearbeiten.",
                expectedPin = "1971",
                onDismiss = {
                    showPinPrompt = false
                    playlistToUnlock = null
                },
                onPinSuccess = {
                    showPinPrompt = false
                    playlistToEdit = playlistToUnlock
                    playlistToUnlock = null
                },
                isEnglish = isEnglish
            )
        }

        // Edit Playlist Dialog
        if (playlistToEdit != null) {
            EditPlaylistDialog(
                playlist = playlistToEdit!!,
                onDismiss = { playlistToEdit = null },
                onSave = { updated ->
                    viewModel.updatePlaylist(updated)
                    playlistToEdit = null
                },
                isEnglish = isEnglish
            )
        }

        // Playlist Import Assistant Dialog
        if (showImportAssistantDialog) {
            PlaylistImportAssistantDialog(
                onDismiss = { showImportAssistantDialog = false },
                onImportConfirmed = { candidates, rawM3uText, fileUri ->
                    val selected = candidates.filter { it.isSelected }
                    viewModel.importCandidatesBatch(selected, rawM3uText, fileUri)
                    showImportAssistantDialog = false
                },
                isEnglish = isEnglish
            )
        }

        // Backup Export Dialog
        if (showBackupDialog) {
            BackupExportDialog(
                onDismiss = { showBackupDialog = false },
                onGenerateBackup = { pwd ->
                    viewModel.exportBackup(pwd)
                },
                playlistsCount = playlists.size,
                isEnglish = isEnglish
            )
        }

        // Backup Restore Dialog
        if (showRestoreDialog) {
            BackupRestoreDialog(
                onDismiss = { showRestoreDialog = false },
                onRestoreBackup = { json, pwd ->
                    viewModel.restoreBackup(json, pwd)
                    showRestoreDialog = false
                },
                isEnglish = isEnglish
            )
        }

        // Installation PIN Lock Dialog (Passwort 1971 erforderlich vor Erstnutzung/Installation)
        if (!isAppUnlocked) {
            InstallationPasswordDialog(
                expectedPin = "1971",
                onPinSuccess = { viewModel.unlockAppWithInstallationPin() },
                isEnglish = isEnglish
            )
        }
    }
}

@Composable
private fun MainScreenContent(
    viewModel: MainViewModel,
    selectedTab: MainTab,
    isEnglish: Boolean,
    onOpenAddPlaylist: () -> Unit = {},
    onOpenAddMacPortal: () -> Unit = {},
    onOpenImportAssistant: () -> Unit = {},
    onEditPlaylist: (PlaylistEntity) -> Unit = {},
    onOpenBackupDialog: () -> Unit = {},
    onOpenRestoreDialog: () -> Unit = {},
    onOpenDownloadManager: () -> Unit = {}
) {
    val filteredLiveChannels by viewModel.filteredLiveChannels.collectAsStateWithLifecycle()
    val filteredMovies by viewModel.filteredMovies.collectAsStateWithLifecycle()
    val filteredSeries by viewModel.filteredSeries.collectAsStateWithLifecycle()
    val filteredRadio by viewModel.filteredRadio.collectAsStateWithLifecycle()
    val favoriteChannels by viewModel.favoriteChannels.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val liveEpgMap by viewModel.liveEpgMap.collectAsStateWithLifecycle()
    val epgGridMap by viewModel.epgGridMap.collectAsStateWithLifecycle()
    val epgSyncState by viewModel.epgSyncState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val activePlaylistId by viewModel.activePlaylistId.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val vodResumeList by viewModel.vodResumeList.collectAsStateWithLifecycle()
    val allVodHistory by viewModel.allVodHistory.collectAsStateWithLifecycle()

    when (selectedTab) {
        MainTab.LIVE_TV -> {
            val displayChannels = filteredLiveChannels

            if (displayChannels.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "📺", fontSize = 48.sp)
                        Text(
                            text = if (isEnglish) "No TV channels found" else "Keine TV-Sender gefunden",
                            color = TextSecondary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (isEnglish) "Check your playlist or category filter" else "Überprüfe deine Playliste oder den Kategoriefilter",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
            val showCountryHeaders = (selectedCategory.equals("ALLE", ignoreCase = true) || selectedCategory.isBlank()) && searchQuery.isBlank()

            val liveListItems = remember(displayChannels, showCountryHeaders) {
                if (!showCountryHeaders) {
                    displayChannels.map { LiveChannelItemEntry.Channel(it) }
                } else {
                    val result = ArrayList<LiveChannelItemEntry>(displayChannels.size + 32)
                    var currentHeaderCountry: String? = null

                    // Single-pass O(N) frequency count
                    val countryCounts = HashMap<String, Int>(32)
                    for (ch in displayChannels) {
                        val code = ch.countryCode.uppercase().trim().ifBlank { if (ch.isDach) "DE" else "INT" }
                        countryCounts[code] = (countryCounts[code] ?: 0) + 1
                    }

                    for (ch in displayChannels) {
                        val code = ch.countryCode.uppercase().trim().ifBlank { if (ch.isDach) "DE" else "INT" }
                        if (code != currentHeaderCountry) {
                            currentHeaderCountry = code
                            val cCount = countryCounts[code] ?: 0
                            val flag = when (code) {
                                "DE" -> "🇩🇪"
                                "AT" -> "🇦🇹"
                                "CH" -> "🇨🇭"
                                "TR" -> "🇹🇷"
                                "UK", "GB" -> "🇬🇧"
                                "US" -> "🇺🇸"
                                "IT" -> "🇮🇹"
                                "FR" -> "🇫🇷"
                                "ES" -> "🇪🇸"
                                "PL" -> "🇵🇱"
                                "NL" -> "🇳🇱"
                                "EXYU" -> "🇷🇸"
                                "RU" -> "🇷🇺"
                                "ADULT" -> "🔞"
                                else -> "🌐"
                            }
                            val cName = when (code) {
                                "DE" -> "Deutschland"
                                "AT" -> "Österreich"
                                "CH" -> "Schweiz"
                                "TR" -> "Türkei"
                                "UK", "GB" -> "United Kingdom"
                                "US" -> "USA"
                                "IT" -> "Italien"
                                "FR" -> "Frankreich"
                                "ES" -> "Spanien"
                                "PL" -> "Polen"
                                "NL" -> "Niederlande"
                                "EXYU" -> "Ex-Jugoslawien"
                                "RU" -> "Russland"
                                "ADULT" -> "18+ Adult"
                                else -> "International"
                            }
                            result.add(
                                LiveChannelItemEntry.Header(
                                    key = "hdr_${code}_${ch.id}",
                                    countryName = cName,
                                    countryCode = code,
                                    flagEmoji = flag,
                                    channelCount = cCount
                                )
                            )
                        }
                        result.add(LiveChannelItemEntry.Channel(ch))
                    }
                    result
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = liveListItems,
                    key = { entry ->
                        when (entry) {
                            is LiveChannelItemEntry.Header -> entry.key
                            is LiveChannelItemEntry.Channel -> entry.channel.id
                        }
                    },
                    contentType = { entry ->
                        when (entry) {
                            is LiveChannelItemEntry.Header -> 0
                            is LiveChannelItemEntry.Channel -> 1
                        }
                    }
                ) { entry ->
                    when (entry) {
                        is LiveChannelItemEntry.Header -> {
                            CountrySectionHeader(
                                countryName = entry.countryName,
                                countryCode = entry.countryCode,
                                flagEmoji = entry.flagEmoji,
                                channelCount = entry.channelCount
                            )
                        }
                        is LiveChannelItemEntry.Channel -> {
                            val ch = entry.channel
                            val livePrograms = liveEpgMap[ch.id]
                            ChannelCard(
                                channel = ch,
                                onClick = { viewModel.playContent(ch) },
                                onToggleFavorite = { viewModel.toggleFavorite(ch) },
                                currentProgram = livePrograms?.first,
                                nextProgram = livePrograms?.second,
                                epgTimezone = settings.epgTimezone,
                                epgTimeOffsetHours = settings.epgTimeOffsetHours
                            )
                        }
                    }
                }
            }
            }
        }
        MainTab.SEARCH -> {
            if (searchQuery.isBlank()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "🔍", fontSize = 48.sp)
                        Text(
                            text = if (isEnglish) "Search channels, movies & series" else "TV Sender, Filme & Serien suchen",
                            color = TextSecondary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (isEnglish) "Enter a name in the search bar above" else "Tippe einen Namen in das Suchfeld oben ein",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            } else if (searchResults.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (isEnglish) "No results found for \"$searchQuery\"" else "Keine Treffer für \"$searchQuery\"",
                        color = TextSecondary,
                        fontSize = 14.sp
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(searchResults, key = { it.id }) { ch ->
                        val livePrograms = liveEpgMap[ch.id]
                        ChannelCard(
                            channel = ch,
                            onClick = { viewModel.playContent(ch) },
                            onToggleFavorite = { viewModel.toggleFavorite(ch) },
                            currentProgram = livePrograms?.first,
                            nextProgram = livePrograms?.second,
                            epgTimezone = settings.epgTimezone,
                            epgTimeOffsetHours = settings.epgTimeOffsetHours
                        )
                    }
                }
            }
        }
        MainTab.FAVORITES -> {
            val favorites = favoriteChannels
            if (favorites.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(text = "❤️", fontSize = 48.sp)
                        Text(
                            text = if (isEnglish) "No favorites yet" else "Noch keine Favoriten gespeichert",
                            color = TextSecondary,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = if (isEnglish) "Tap the heart icon on any channel to add it here" else "Tippe auf das Herz-Symbol bei einem Sender, um ihn hinzuzufügen",
                            color = TextMuted,
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(favorites, key = { it.id }) { ch ->
                        val livePrograms = liveEpgMap[ch.id]
                        ChannelCard(
                            channel = ch,
                            onClick = { viewModel.playContent(ch) },
                            onToggleFavorite = { viewModel.toggleFavorite(ch) },
                            currentProgram = livePrograms?.first,
                            nextProgram = livePrograms?.second,
                            epgTimezone = settings.epgTimezone,
                            epgTimeOffsetHours = settings.epgTimeOffsetHours
                        )
                    }
                }
            }
        }
        MainTab.CONTINUE_WATCHING -> {
            VodContinueWatchingScreen(
                resumeItems = vodResumeList,
                allVodItems = allVodHistory,
                liveTvChannels = filteredLiveChannels.take(20),
                liveEpgMap = liveEpgMap,
                settings = settings,
                onResumeItem = { item -> viewModel.resumeVodItem(item) },
                onRestartItem = { item ->
                    viewModel.resumeVodItem(item.copy(lastPositionSeconds = 0L))
                },
                onDeleteItem = { item -> viewModel.deleteVodResumeItem(item) },
                onClearAllVodHistory = { viewModel.clearAllVodHistory() },
                onPlayLiveChannel = { viewModel.playContent(it) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                isEnglish = isEnglish
            )
        }
        MainTab.RADIO -> {
            RadioExplorer(
                radioStations = filteredRadio,
                onPlayRadio = { viewModel.playContent(it) },
                onToggleFavorite = { viewModel.toggleFavorite(it) },
                isEnglish = isEnglish
            )
        }
        MainTab.MOVIES -> {
            val recordings by viewModel.recordings.collectAsStateWithLifecycle()
            MovieExplorer(
                movies = filteredMovies,
                recordings = recordings,
                onPlayMovie = { viewModel.playContent(it) },
                onDownloadMovie = { viewModel.downloadVodContent(it) },
                onOpenDownloadManager = onOpenDownloadManager,
                isEnglish = isEnglish
            )
        }
        MainTab.SERIES -> {
            val recordings by viewModel.recordings.collectAsStateWithLifecycle()
            SeriesExplorer(
                seriesChannels = filteredSeries,
                recordings = recordings,
                onPlayEpisode = { viewModel.playContent(it) },
                onDownloadEpisode = { viewModel.downloadVodContent(it) },
                onOpenDownloadManager = onOpenDownloadManager,
                onFetchEpisodes = { viewModel.fetchSeriesEpisodes(it) },
                isEnglish = isEnglish
            )
        }
        MainTab.LIVE_TV_LIGHT -> {
            LiveTvLightView(
                onPlayInAppPlayer = { channelItem -> viewModel.playContent(channelItem) },
                isEnglish = isEnglish
            )
        }
        MainTab.WEB_STREAMS -> {
            WebStreamBrowserView(
                onPlayDetectedStream = { url, title -> viewModel.playStreamDirect(url, title) },
                isEnglish = isEnglish
            )
        }
        MainTab.EPG_GUIDE -> {
            EpgGuideView(
                channels = filteredLiveChannels,
                onSelectChannel = { viewModel.playContent(it) },
                epgTimezone = settings.epgTimezone,
                epgTimeOffsetHours = settings.epgTimeOffsetHours,
                isEnglish = isEnglish,
                epgGridMap = epgGridMap,
                syncState = epgSyncState,
                onSyncEpg = { viewModel.preloadEpgIfNeeded(force = true) },
                loadChannelSchedule = { viewModel.getFullScheduleForChannel(it) }
            )
        }
        MainTab.SETTINGS -> {
            SettingsView(
                settings = settings,
                playlists = playlists,
                recordings = viewModel.recordings.collectAsStateWithLifecycle().value,
                activePlaylistId = activePlaylistId,
                onSelectPlaylist = { viewModel.switchPlaylist(it) },
                onUpdateCachingMode = { viewModel.updateCachingMode(it) },
                onUpdatePreferredPlayer = { viewModel.updatePreferredPlayer(it) },
                onToggleBackgroundPlayback = { viewModel.toggleBackgroundPlayback(it) },
                onUpdateLanguage = { viewModel.updateLanguage(it) },
                onOpenAddPlaylist = onOpenAddPlaylist,
                onOpenAddMacPortal = onOpenAddMacPortal,
                onOpenImportAssistant = onOpenImportAssistant,
                onUpdatePlaylist = onEditPlaylist,
                onDeletePlaylist = { viewModel.deletePlaylist(it) },
                onRefreshPlaylist = { viewModel.refreshPlaylist(it) },
                onOpenBackupDialog = onOpenBackupDialog,
                onOpenRestoreDialog = onOpenRestoreDialog,
                onDeleteRecording = { viewModel.deleteRecording(it) },
                onPlayRecording = { viewModel.playRecording(it) },
                onCancelDownload = { viewModel.cancelDownload(it) },
                onDeleteAllPlaylists = { viewModel.deleteAllPlaylists() },
                onUpdateSyncOnlyGermanWhenGerman = { viewModel.updateSyncOnlyGermanWhenGerman(it) },
                onOptimizeDatabase = { viewModel.optimizeDatabasePerformance() },
                onUpdateAutoUpdateOnStart = { viewModel.updateAutoUpdateOnStart(it) },
                onUpdateNexusFullScreen = { viewModel.updateNexusFullScreenEnabled(it) },
                onUpdateAspectRatio = { viewModel.updateAspectRatio(it) },
                onUpdateEpgTimezone = { viewModel.updateEpgTimezone(it) },
                onUpdateEpgTimeOffsetHours = { viewModel.updateEpgTimeOffsetHours(it) },
                onUpdateProviderEpgOffset = { p, o -> viewModel.updateProviderEpgOffset(p, o) },
                onForceEpgRemap = { viewModel.forceEpgRemap() },
                onUpdateCustomEpgUrl = { viewModel.updateCustomEpgUrl(it) },
                onTriggerEpgSync = { viewModel.triggerEpgSync(it) },
                onSyncBothEpgFeeds = { viewModel.triggerSyncBothNewFeeds() },
                onClearAllEpg = { viewModel.clearAllEpgEntries() },
                syncState = viewModel.epgSyncState.collectAsStateWithLifecycle().value,
                onLockApp = { viewModel.lockApp() },
                isEnglish = isEnglish
            )
        }
        else -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = selectedTab.name, color = TextPrimary)
            }
        }
    }
}

private sealed interface LiveChannelItemEntry {
    data class Header(
        val key: String,
        val countryName: String,
        val countryCode: String,
        val flagEmoji: String,
        val channelCount: Int
    ) : LiveChannelItemEntry

    data class Channel(
        val channel: com.example.data.model.ChannelItem
    ) : LiveChannelItemEntry
}

