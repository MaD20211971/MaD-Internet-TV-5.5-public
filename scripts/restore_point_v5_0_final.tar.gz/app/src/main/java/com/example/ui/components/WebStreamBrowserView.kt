package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChromeReaderMode
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentRose
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.util.concurrent.TimeUnit

private const val WEB_TV_PIN_CODE = "1971"

data class WebPortalPreset(
    val name: String,
    val url: String,
    val category: String,
    val description: String,
    val badge: String,
    val badgeColor: Color,
    val iconEmoji: String
)

data class DirectWebChannel(
    val id: String,
    val name: String,
    val category: String,
    val streamUrl: String,
    val webUrl: String,
    val logoTag: String,
    val resolution: String = "1080p HD",
    val is2ix2: Boolean = true
)

enum class WebTvMode {
    DIRECT_CHANNELS,   // 100% crash-safe direct stream player (Nexus HD Player)
    CUSTOM_TAB_PORTAL, // Chrome Custom Tab High-Speed Browser (Android 16 / S25 Ultra Optimized)
    SAFE_EMBEDDED      // Sandboxed In-App WebView with Full Crash Guards
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebStreamBrowserView(
    onPlayDetectedStream: (streamUrl: String, title: String) -> Unit,
    isEnglish: Boolean = false
) {
    // Strikter PIN-Schutz für die Rubrik Web TV (PIN: 1971, 12-Stellen-Vorlage):
    // Solange nicht entsperrt, wird keinerlei Web-TV-Inhalt gerendert oder preisgegeben.
    var isWebTvUnlocked by remember { mutableStateOf(false) }

    if (!isWebTvUnlocked) {
        WebTvPinLockScreen(
            expectedPin = WEB_TV_PIN_CODE,
            onPinSuccess = { isWebTvUnlocked = true },
            isEnglish = isEnglish
        )
        return
    }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedMode by remember { mutableStateOf(WebTvMode.DIRECT_CHANNELS) }

    // Curated Portals (2ix2.com, Movie2k, Kool.ws, Megakino, Nydus)
    val portals = remember {
        listOf(
            WebPortalPreset(
                name = "2ix2.com",
                url = "https://www.2ix2.com/",
                category = "Deutsche TV Sender",
                description = "Kostenloses deutsches Live TV (ARD, ZDF, RTL, Pro7, etc.)",
                badge = "German Live TV",
                badgeColor = AccentEmerald,
                iconEmoji = "📺"
            ),
            WebPortalPreset(
                name = "Nydus Live Stream",
                url = "http://nydus.org/stream/live",
                category = "Live TV & Sport",
                description = "Live TV & Sport Streams, Events und Live-Übertragungen",
                badge = "Live Streams",
                badgeColor = AccentCyan,
                iconEmoji = "📡"
            ),
            WebPortalPreset(
                name = "Movie2k",
                url = "https://movie2k.cx/",
                category = "Filme & Serien",
                description = "Aktuelle Filme, Serien und Kinofilme kostenlos im Stream",
                badge = "Filme & Serien",
                badgeColor = GoldPrimary,
                iconEmoji = "🎬"
            ),
            WebPortalPreset(
                name = "Kool.ws",
                url = "https://kool.ws/",
                category = "Kino & Video On Demand",
                description = "Kostenlose Kinofilme, beliebte Serien und Video-Streams",
                badge = "Kino Streams",
                badgeColor = AccentRose,
                iconEmoji = "🍿"
            ),
            WebPortalPreset(
                name = "Megakino",
                url = "http://megakino18.com/",
                category = "Filme & Serien",
                description = "Große Auswahl an Spielfilmen, Blockbustern und Serien",
                badge = "Blockbuster",
                badgeColor = GoldDark,
                iconEmoji = "🎥"
            )
        )
    }

    // Direct, crystal clear 2ix2 & DACH Web TV Channels (native Nexus Player streams)
    val directChannels = remember {
        listOf(
            DirectWebChannel(
                id = "ard",
                name = "Das Erste (ARD)",
                category = "Öffentlich-Rechtlich",
                streamUrl = "https://mcdn.daserste.de/daserste/de/master.m3u8",
                webUrl = "https://www.2ix2.com/das-erste-live-stream/",
                logoTag = "ARD"
            ),
            DirectWebChannel(
                id = "zdf",
                name = "ZDF HD",
                category = "Öffentlich-Rechtlich",
                streamUrl = "https://zdf-hls-15.akamaized.net/hls/live/2016498/de/veryhigh/master.m3u8",
                webUrl = "https://www.2ix2.com/zdf-live-stream/",
                logoTag = "ZDF"
            ),
            DirectWebChannel(
                id = "arte",
                name = "ARTE Deutsch HD",
                category = "Kultur & Doku",
                streamUrl = "https://artesimulcast.akamaized.net/hls/live/2031003/artelive_de/master.m3u8",
                webUrl = "https://www.2ix2.com/arte-live-stream/",
                logoTag = "ARTE"
            ),
            DirectWebChannel(
                id = "3sat",
                name = "3sat HD",
                category = "Kultur & Doku",
                streamUrl = "https://zdf-hls-18.akamaized.net/hls/live/2016501/de/veryhigh/master.m3u8",
                webUrl = "https://www.2ix2.com/3sat-live-stream/",
                logoTag = "3SAT"
            ),
            DirectWebChannel(
                id = "kika",
                name = "KiKA Kinderkanal HD",
                category = "Kinder",
                streamUrl = "https://kika-hls.akamaized.net/hls/live/2022693/live/master.m3u8",
                webUrl = "https://www.2ix2.com/kika-live-stream/",
                logoTag = "KIKA"
            ),
            DirectWebChannel(
                id = "phoenix",
                name = "PHOENIX HD",
                category = "Doku & Politik",
                streamUrl = "https://zdf-hls-19.akamaized.net/hls/live/2016502/de/veryhigh/master.m3u8",
                webUrl = "https://www.2ix2.com/phoenix-live-stream/",
                logoTag = "PHOENIX"
            ),
            DirectWebChannel(
                id = "tagesschau24",
                name = "tagesschau24 HD",
                category = "Nachrichten",
                streamUrl = "https://tagesschau.akamaized.net/hls/live/2020115/tagesschau/tagesschau_1/master.m3u8",
                webUrl = "https://www.2ix2.com/tagesschau24-live-stream/",
                logoTag = "TS24"
            ),
            DirectWebChannel(
                id = "welt",
                name = "WELT Nachrichtensender",
                category = "Nachrichten",
                streamUrl = "https://live2.welt.de/live2/hls/master.m3u8",
                webUrl = "https://www.2ix2.com/welt-live-stream/",
                logoTag = "WELT"
            ),
            DirectWebChannel(
                id = "zdfinfo",
                name = "ZDFinfo HD",
                category = "Doku & Wissen",
                streamUrl = "https://zdf-hls-17.akamaized.net/hls/live/2016500/de/veryhigh/master.m3u8",
                webUrl = "https://www.2ix2.com/zdfinfo-live-stream/",
                logoTag = "INFO"
            ),
            DirectWebChannel(
                id = "zdfneo",
                name = "ZDFneo HD",
                category = "Unterhaltung",
                streamUrl = "https://zdf-hls-16.akamaized.net/hls/live/2016499/de/veryhigh/master.m3u8",
                webUrl = "https://www.2ix2.com/zdfneo-live-stream/",
                logoTag = "NEO"
            ),
            DirectWebChannel(
                id = "wdr",
                name = "WDR Köln HD",
                category = "Regional (Drittes)",
                streamUrl = "https://wdrfsgeo.akamaized.net/hls/live/2015750/wdrfsgeo/master.m3u8",
                webUrl = "https://www.2ix2.com/wdr-live-stream/",
                logoTag = "WDR"
            ),
            DirectWebChannel(
                id = "ndr",
                name = "NDR Fernsehen HD",
                category = "Regional (Drittes)",
                streamUrl = "https://ndrfs-lh.akamaihd.net/i/ndrfs_nds@430233/master.m3u8",
                webUrl = "https://www.2ix2.com/ndr-live-stream/",
                logoTag = "NDR"
            ),
            DirectWebChannel(
                id = "swr",
                name = "SWR Fernsehen BW HD",
                category = "Regional (Drittes)",
                streamUrl = "https://swrbw-hls.akamaized.net/hls/live/2018674/swrbw/master.m3u8",
                webUrl = "https://www.2ix2.com/swr-live-stream/",
                logoTag = "SWR"
            ),
            DirectWebChannel(
                id = "br",
                name = "BR Fernsehen Süd HD",
                category = "Regional (Drittes)",
                streamUrl = "https://brfs-lh.akamaihd.net/i/brfs_sued@119890/master.m3u8",
                webUrl = "https://www.2ix2.com/br-live-stream/",
                logoTag = "BR"
            ),
            DirectWebChannel(
                id = "servustv",
                name = "ServusTV On",
                category = "Sport & Doku",
                streamUrl = "https://rbmn-live.akamaized.net/hls/live/2002825/geoSTVDEweb/master.m3u8",
                webUrl = "https://www.2ix2.com/servustv-live-stream/",
                logoTag = "SERVUS"
            ),
            DirectWebChannel(
                id = "rtl",
                name = "RTL Television",
                category = "Privatsender",
                streamUrl = "https://www.2ix2.com/rtl-live-stream/",
                webUrl = "https://www.2ix2.com/rtl-live-stream/",
                logoTag = "RTL"
            ),
            DirectWebChannel(
                id = "pro7",
                name = "ProSieben HD",
                category = "Privatsender",
                streamUrl = "https://www.2ix2.com/prosieben-live-stream/",
                webUrl = "https://www.2ix2.com/prosieben-live-stream/",
                logoTag = "PRO7"
            ),
            DirectWebChannel(
                id = "sat1",
                name = "SAT.1",
                category = "Privatsender",
                streamUrl = "https://www.2ix2.com/sat1-live-stream/",
                webUrl = "https://www.2ix2.com/sat1-live-stream/",
                logoTag = "SAT1"
            ),
            DirectWebChannel(
                id = "vox",
                name = "VOX HD",
                category = "Privatsender",
                streamUrl = "https://www.2ix2.com/vox-live-stream/",
                webUrl = "https://www.2ix2.com/vox-live-stream/",
                logoTag = "VOX"
            ),
            DirectWebChannel(
                id = "kabel1",
                name = "Kabel Eins",
                category = "Privatsender",
                streamUrl = "https://www.2ix2.com/kabel-eins-live-stream/",
                webUrl = "https://www.2ix2.com/kabel-eins-live-stream/",
                logoTag = "K1"
            ),
            DirectWebChannel(
                id = "rtl2",
                name = "RTL II",
                category = "Privatsender",
                streamUrl = "https://www.2ix2.com/rtl2-live-stream/",
                webUrl = "https://www.2ix2.com/rtl2-live-stream/",
                logoTag = "RTL2"
            ),
            DirectWebChannel(
                id = "super_rtl",
                name = "Super RTL",
                category = "Unterhaltung",
                streamUrl = "https://www.2ix2.com/super-rtl-live-stream/",
                webUrl = "https://www.2ix2.com/super-rtl-live-stream/",
                logoTag = "SRTL"
            ),
            DirectWebChannel(
                id = "ntv",
                name = "n-tv Nachrichten",
                category = "Nachrichten",
                streamUrl = "https://www.2ix2.com/ntv-live-stream/",
                webUrl = "https://www.2ix2.com/ntv-live-stream/",
                logoTag = "NTV"
            ),
            DirectWebChannel(
                id = "nitro",
                name = "NITRO",
                category = "Unterhaltung",
                streamUrl = "https://www.2ix2.com/nitro-live-stream/",
                webUrl = "https://www.2ix2.com/nitro-live-stream/",
                logoTag = "NITRO"
            ),
            DirectWebChannel(
                id = "dmax",
                name = "DMAX Deutschland",
                category = "Unterhaltung",
                streamUrl = "https://www.2ix2.com/dmax-live-stream/",
                webUrl = "https://www.2ix2.com/dmax-live-stream/",
                logoTag = "DMAX"
            ),
            DirectWebChannel(
                id = "sport1",
                name = "SPORT1 HD",
                category = "Sport",
                streamUrl = "https://www.2ix2.com/sport1-live-stream/",
                webUrl = "https://www.2ix2.com/sport1-live-stream/",
                logoTag = "SPORT1"
            ),
            DirectWebChannel(
                id = "eurosport",
                name = "Eurosport 1",
                category = "Sport",
                streamUrl = "https://www.2ix2.com/eurosport-live-stream/",
                webUrl = "https://www.2ix2.com/eurosport-live-stream/",
                logoTag = "EURO1"
            ),
            DirectWebChannel(
                id = "orf1",
                name = "ORF 1 HD",
                category = "Österreich (ORF)",
                streamUrl = "https://www.2ix2.com/orf1-live-stream/",
                webUrl = "https://www.2ix2.com/orf1-live-stream/",
                logoTag = "ORF1"
            ),
            DirectWebChannel(
                id = "orf2",
                name = "ORF 2 HD",
                category = "Österreich (ORF)",
                streamUrl = "https://www.2ix2.com/orf2-live-stream/",
                webUrl = "https://www.2ix2.com/orf2-live-stream/",
                logoTag = "ORF2"
            ),
            DirectWebChannel(
                id = "srf1",
                name = "SRF 1 HD",
                category = "Schweiz (SRF)",
                streamUrl = "https://www.2ix2.com/srf1-live-stream/",
                webUrl = "https://www.2ix2.com/srf1-live-stream/",
                logoTag = "SRF1"
            ),
            DirectWebChannel(
                id = "srf2",
                name = "SRF zwei HD",
                category = "Schweiz (SRF)",
                streamUrl = "https://www.2ix2.com/srf2-live-stream/",
                webUrl = "https://www.2ix2.com/srf2-live-stream/",
                logoTag = "SRF2"
            ),
            DirectWebChannel(
                id = "nydus_live",
                name = "Nydus Live Stream",
                category = "Live TV & Sport",
                streamUrl = "http://nydus.org/stream/live",
                webUrl = "http://nydus.org/stream/live",
                logoTag = "NYDUS",
                resolution = "Live HD",
                is2ix2 = false
            ),
            DirectWebChannel(
                id = "movie2k_portal",
                name = "Movie2k.cx",
                category = "Filme & Serien",
                streamUrl = "https://movie2k.cx/",
                webUrl = "https://movie2k.cx/",
                logoTag = "M2K",
                resolution = "HD / VoD",
                is2ix2 = false
            ),
            DirectWebChannel(
                id = "kool_ws_portal",
                name = "Kool.ws",
                category = "Filme & Serien",
                streamUrl = "https://kool.ws/",
                webUrl = "https://kool.ws/",
                logoTag = "KOOL",
                resolution = "HD / VoD",
                is2ix2 = false
            ),
            DirectWebChannel(
                id = "megakino_portal",
                name = "Megakino",
                category = "Filme & Serien",
                streamUrl = "http://megakino18.com/",
                webUrl = "http://megakino18.com/",
                logoTag = "MEGA",
                resolution = "HD / VoD",
                is2ix2 = false
            )
        )
    }

    // Function to launch high-performance Chrome Custom Tab (100% crash proof on Android 16 / S25 Ultra)
    val launchCustomTab: (String) -> Unit = { url ->
        try {
            val darkParams = CustomTabColorSchemeParams.Builder()
                .setToolbarColor(ObsidianBlack.toArgb())
                .setSecondaryToolbarColor(DarkNavyCard.toArgb())
                .setNavigationBarColor(ObsidianBlack.toArgb())
                .build()

            val customTabsIntent = CustomTabsIntent.Builder()
                .setDefaultColorSchemeParams(darkParams)
                .setShowTitle(true)
                .setUrlBarHidingEnabled(true)
                .setShareState(CustomTabsIntent.SHARE_STATE_OFF)
                .build()

            customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            customTabsIntent.launchUrl(context, Uri.parse(url))
        } catch (e: Exception) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(browserIntent)
            } catch (err: Exception) {
                Toast.makeText(context, "Browser konnte nicht gestartet werden", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
            .testTag("web_stream_browser_screen")
    ) {
        // Security Header Bar with instant Re-Lock action
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavyCard)
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = AccentEmerald,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isEnglish) "Web TV Unlocked (PIN Protected)" else "Web TV freigeschaltet (PIN-geschützt)",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            OutlinedButton(
                onClick = { isWebTvUnlocked = false },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("web_tv_relock_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = if (isEnglish) "Lock Web TV" else "Web TV sperren",
                    tint = GoldPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isEnglish) "Lock" else "Sperren",
                    color = GoldPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Mode Selector Tab Row
        TabRow(
            selectedTabIndex = selectedMode.ordinal,
            containerColor = DarkNavyCard,
            contentColor = GoldPrimary,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedMode.ordinal]),
                    color = GoldPrimary,
                    height = 3.dp
                )
            }
        ) {
            Tab(
                selected = selectedMode == WebTvMode.DIRECT_CHANNELS,
                onClick = { selectedMode = WebTvMode.DIRECT_CHANNELS },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LiveTv, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isEnglish) "Live TV Channels" else "2ix2 & Web TV",
                            fontWeight = if (selectedMode == WebTvMode.DIRECT_CHANNELS) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                }
            )

            Tab(
                selected = selectedMode == WebTvMode.CUSTOM_TAB_PORTAL,
                onClick = { selectedMode = WebTvMode.CUSTOM_TAB_PORTAL },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isEnglish) "Web Portals & Cinema" else "Web-Portale & Kino",
                            fontWeight = if (selectedMode == WebTvMode.CUSTOM_TAB_PORTAL) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                }
            )

            Tab(
                selected = selectedMode == WebTvMode.SAFE_EMBEDDED,
                onClick = { selectedMode = WebTvMode.SAFE_EMBEDDED },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ChromeReaderMode, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isEnglish) "In-App Browser" else "In-App Ansicht",
                            fontWeight = if (selectedMode == WebTvMode.SAFE_EMBEDDED) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                }
            )
        }

        when (selectedMode) {
            WebTvMode.DIRECT_CHANNELS -> {
                // Direct Web Channels Screen: Open directly in Chrome Custom Tab / Web Browser
                DirectChannelsScreen(
                    channels = directChannels,
                    onPlayChannel = { ch ->
                        launchCustomTab(ch.webUrl)
                    },
                    onOpenInBrowser = { ch ->
                        launchCustomTab(ch.webUrl)
                    },
                    isEnglish = isEnglish
                )
            }

            WebTvMode.CUSTOM_TAB_PORTAL -> {
                // High-performance Portals Screen for 2ix2.com
                WebPortalsHubScreen(
                    portals = portals,
                    onOpenPortal = { portal ->
                        launchCustomTab(portal.url)
                    },
                    onCustomUrlLaunch = { url ->
                        launchCustomTab(url)
                    },
                    isEnglish = isEnglish
                )
            }

            WebTvMode.SAFE_EMBEDDED -> {
                // Sandboxed In-App Browser with Android 16 Safety Guards
                SafeEmbeddedBrowserScreen(
                    onPlayDetectedStream = onPlayDetectedStream,
                    onLaunchExternal = launchCustomTab,
                    isEnglish = isEnglish
                )
            }
        }
    }
}

/**
 * Vollflächige, blickdichte PIN-Sperre für die Rubrik Web TV (PIN: 1971).
 * Kein Zugang und keine Einsicht ohne korrekten PIN.
 * Die PIN-Vorlage zeigt stets 12 Stellen an (PinTwelveSlotTemplate).
 */
@Composable
private fun WebTvPinLockScreen(
    expectedPin: String = WEB_TV_PIN_CODE,
    onPinSuccess: () -> Unit,
    isEnglish: Boolean = false
) {
    var enteredPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }

    fun verifyPin(candidate: String) {
        if (candidate == expectedPin) {
            onPinSuccess()
        } else {
            isError = true
            enteredPin = ""
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 20.dp)
            .testTag("web_tv_pin_lock_screen"),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(22.dp))
                .border(1.5.dp, GoldPrimary, RoundedCornerShape(22.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(GoldPrimary.copy(alpha = 0.15f))
                        .border(1.dp, GoldPrimary.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = if (isEnglish) "Web TV Locked" else "Web TV gesperrt",
                        tint = GoldPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = if (isEnglish) "Web TV — PIN Protected" else "Rubrik Web TV — PIN-geschützt",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldPrimary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (isEnglish)
                        "No access and no view without valid PIN authorization."
                    else
                        "Kein Zugang und keine Einsicht ohne gültige PIN-Autorisierung.",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                // 12-Stellen PIN-Vorlage (zeigt exakt 12 visuelle Stellen an)
                PinTwelveSlotTemplate(
                    enteredLength = enteredPin.length,
                    isError = isError
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = enteredPin,
                    onValueChange = { input ->
                        val digits = input.filter { it.isDigit() }
                        if (digits.length <= 12) {
                            enteredPin = digits
                            isError = false
                            if (digits == expectedPin) {
                                verifyPin(digits)
                            }
                        }
                    },
                    label = { Text(if (isEnglish) "PIN Template (12 Digits)" else "PIN-Vorlage (12 Stellen)") },
                    placeholder = { Text("•••• •••• ••••") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.NumberPassword,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { verifyPin(enteredPin) }),
                    singleLine = true,
                    isError = isError,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("web_tv_pin_input_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface,
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = if (isError) AccentRose else BorderGlow.copy(alpha = 0.5f),
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    )
                )

                if (isError) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isEnglish)
                            "Incorrect PIN. Access denied."
                        else
                            "Falscher PIN! Kein Zugang zu Web TV.",
                        color = AccentRose,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // TV Remote & Touch Numpad (1-9, C, 0, OK)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val rows = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("C", "0", "OK")
                    )

                    rows.forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { key ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(46.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(
                                            when (key) {
                                                "OK" -> GoldPrimary
                                                "C" -> DarkSurfaceElevated
                                                else -> DarkSurface
                                            }
                                        )
                                        .border(
                                            1.dp,
                                            if (key == "OK") GoldLight else BorderGlow.copy(alpha = 0.3f),
                                            RoundedCornerShape(10.dp)
                                        )
                                        .clickable {
                                            when (key) {
                                                "C" -> {
                                                    if (enteredPin.isNotEmpty()) {
                                                        enteredPin = enteredPin.dropLast(1)
                                                    }
                                                    isError = false
                                                }
                                                "OK" -> verifyPin(enteredPin)
                                                else -> {
                                                    if (enteredPin.length < 12) {
                                                        val updated = enteredPin + key
                                                        enteredPin = updated
                                                        isError = false
                                                        if (updated == expectedPin) {
                                                            verifyPin(updated)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        .testTag("web_tv_pin_key_$key"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (key == "C") {
                                        Icon(
                                            imageVector = Icons.Default.Backspace,
                                            contentDescription = "Backspace",
                                            tint = TextSecondary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    } else {
                                        Text(
                                            text = key,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (key == "OK") Color.Black else TextPrimary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { verifyPin(enteredPin) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("web_tv_pin_unlock_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color.Black,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isEnglish) "Unlock Web TV" else "Web TV freischalten",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

/**
 * 1. Direct Channels Screen: Lists curated 2ix2 and German Web TV Channels
 */
@Composable
private fun DirectChannelsScreen(
    channels: List<DirectWebChannel>,
    onPlayChannel: (DirectWebChannel) -> Unit,
    onOpenInBrowser: (DirectWebChannel) -> Unit,
    isEnglish: Boolean
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }

    val categories = remember(channels) {
        listOf("Alle") + channels.map { it.category }.distinct()
    }

    val filteredChannels = remember(channels, searchQuery, selectedCategory) {
        channels.filter { ch ->
            val matchesCategory = selectedCategory == null || selectedCategory == "Alle" || ch.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() || ch.name.contains(searchQuery, ignoreCase = true) || ch.category.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        // Info Header Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .border(1.dp, BorderGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(AccentEmerald.copy(alpha = 0.15f))
                        .border(1.dp, AccentEmerald.copy(alpha = 0.4f), RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Speed, contentDescription = null, tint = AccentEmerald, modifier = Modifier.size(22.dp))
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isEnglish) "2ix2.com & Web TV Direct Channels" else "2ix2.com & Web TV Sender",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = GoldPrimary
                    )
                    Text(
                        text = if (isEnglish) "Opens directly in Web Browser • Fast & Crash-proof" else "Öffnet direkt im Webbrowser • Schnell & 100% stabil",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(if (isEnglish) "Search channel (e.g. RTL, Pro7, ARD)..." else "Sender suchen (z.B. RTL, Pro7, ARD)...", fontSize = 12.sp, color = TextMuted) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = TextPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = BorderGlow.copy(alpha = 0.5f),
                focusedContainerColor = DarkSurface,
                unfocusedContainerColor = DarkSurface
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Category Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { cat ->
                val isSelected = (selectedCategory == null && cat == "Alle") || selectedCategory == cat
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) GoldPrimary else DarkSurfaceElevated)
                        .border(1.dp, if (isSelected) GoldLight else BorderGlow.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .clickable {
                            selectedCategory = if (cat == "Alle") null else cat
                        }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = cat,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) ObsidianBlack else TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Grid of Channels
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filteredChannels, key = { it.id }) { ch ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, BorderGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .clickable { onPlayChannel(ch) },
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkSurfaceElevated)
                                    .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = ch.logoTag,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = GoldPrimary
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AccentCyan.copy(alpha = 0.15f))
                                    .padding(horizontal = 5.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = ch.resolution,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentCyan
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = ch.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )

                        Text(
                            text = ch.category,
                            fontSize = 10.sp,
                            color = TextSecondary,
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Button(
                                onClick = { onPlayChannel(ch) },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(6.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f).height(32.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = ObsidianBlack, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(2.dp))
                                Text(text = "Play", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }

                            IconButton(
                                onClick = { onOpenInBrowser(ch) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "2ix2 Web", tint = TextMuted, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 2. Web Portals Hub Screen: Fast Chrome Custom Tab launcher for 2ix2.com
 */
@Composable
private fun WebPortalsHubScreen(
    portals: List<WebPortalPreset>,
    onOpenPortal: (WebPortalPreset) -> Unit,
    onCustomUrlLaunch: (String) -> Unit,
    isEnglish: Boolean
) {
    var customUrlInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            // Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🚀", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "High Performance Web-Portale",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldPrimary
                            )
                            Text(
                                text = "Direktbeschleunigter Modus (100% absturzsicher & HDR fähig)",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isEnglish)
                            "Opens 2ix2, Movie2k, Kool.ws, Megakino and Nydus Live inside hardware accelerated browser engine with full video playback and zero crashes."
                        else
                            "Öffnet 2ix2.com, Movie2k, Kool.ws, Megakino und Nydus.org in der hardwarebeschleunigten Browser-Engine mit voller Video-Wiedergabe und ohne App-Abstürze.",
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }
        }

        item {
            Text(
                text = if (isEnglish) "Popular Streaming Portals:" else "Beliebte Streaming-Portale:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = GoldLight
            )
        }

        items(portals) { portal ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .border(1.dp, BorderGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .clickable { onOpenPortal(portal) },
                colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(DarkSurfaceElevated)
                                .border(1.dp, portal.badgeColor.copy(alpha = 0.4f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = portal.iconEmoji, fontSize = 22.sp)
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = portal.name,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(portal.badgeColor.copy(alpha = 0.15f))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = portal.badge,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = portal.badgeColor
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = portal.description,
                                fontSize = 11.sp,
                                color = TextSecondary,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { onOpenPortal(portal) },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Launch, contentDescription = null, tint = ObsidianBlack, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Öffnen", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isEnglish) "Open custom URL:" else "Eigene Webadresse öffnen:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = customUrlInput,
                            onValueChange = { customUrlInput = it },
                            placeholder = { Text("https://...", fontSize = 12.sp, color = TextMuted) },
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp),
                            singleLine = true,
                            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = TextPrimary),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = BorderGlow.copy(alpha = 0.5f),
                                focusedContainerColor = DarkNavyBackground,
                                unfocusedContainerColor = DarkNavyBackground
                            ),
                            shape = RoundedCornerShape(8.dp)
                        )

                        Button(
                            onClick = {
                                var target = customUrlInput.trim()
                                if (target.isNotBlank()) {
                                    if (!target.startsWith("http://") && !target.startsWith("https://")) {
                                        target = "https://$target"
                                    }
                                    onCustomUrlLaunch(target)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(46.dp)
                        ) {
                            Text("Start", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 3. Safe Embedded Browser Screen: Hardened WebView with zero crash propagation
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun SafeEmbeddedBrowserScreen(
    onPlayDetectedStream: (streamUrl: String, title: String) -> Unit,
    onLaunchExternal: (String) -> Unit,
    isEnglish: Boolean
) {
    val context = LocalContext.current
    var currentUrl by remember { mutableStateOf("https://www.2ix2.com/") }
    var inputUrlText by remember { mutableStateOf("https://www.2ix2.com/") }
    var pageTitle by remember { mutableStateOf("2ix2.com - Live TV") }
    var pageLoadingProgress by remember { mutableFloatStateOf(0f) }
    var isLoading by remember { mutableStateOf(false) }
    var detectedStreamUrl by remember { mutableStateOf<String?>(null) }
    var detectedStreamTitle by remember { mutableStateOf("Stream") }
    var webViewError by remember { mutableStateOf<String?>(null) }
    var webViewKey by remember { mutableIntStateOf(1) }

    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    BackHandler(enabled = webViewRef?.canGoBack() == true) {
        try {
            webViewRef?.goBack()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    DisposableEffect(webViewKey) {
        onDispose {
            try {
                webViewRef?.let { wb ->
                    wb.stopLoading()
                    wb.loadUrl("about:blank")
                    (wb.parent as? ViewGroup)?.removeView(wb)
                    wb.destroy()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
    ) {
        // Navigation Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavyCard)
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            IconButton(
                onClick = { webViewRef?.goBack() },
                enabled = webViewRef?.canGoBack() == true,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = if (webViewRef?.canGoBack() == true) GoldPrimary else TextMuted)
            }

            IconButton(
                onClick = { webViewRef?.reload() },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = "Reload", tint = GoldLight)
            }

            OutlinedTextField(
                value = inputUrlText,
                onValueChange = { inputUrlText = it },
                modifier = Modifier
                    .weight(1f)
                    .height(42.dp),
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 12.sp, color = TextPrimary),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = BorderGlow.copy(alpha = 0.5f),
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(8.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                keyboardActions = KeyboardActions(
                    onGo = {
                        var target = inputUrlText.trim()
                        if (!target.startsWith("http://") && !target.startsWith("https://")) {
                            target = "https://$target"
                        }
                        currentUrl = target
                        detectedStreamUrl = null
                        webViewRef?.loadUrl(target)
                    }
                )
            )

            // Open in High-Speed Custom Tab
            IconButton(
                onClick = { onLaunchExternal(currentUrl) },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.OpenInNew, contentDescription = "Open in Chrome/Samsung", tint = GoldPrimary)
            }
        }

        // Quick Portal Shortcuts (2ix2, Nydus, Movie2k, Kool.ws, Megakino)
        val quickWebSites = remember {
            listOf(
                "2ix2 TV" to "https://www.2ix2.com/",
                "Nydus Live" to "http://nydus.org/stream/live",
                "Movie2k" to "https://movie2k.cx/",
                "Kool.ws" to "https://kool.ws/",
                "Megakino" to "http://megakino18.com/"
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(DarkNavyCard)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickWebSites.forEach { (label, siteUrl) ->
                val isCurrent = currentUrl.startsWith(siteUrl.removeSuffix("/"))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isCurrent) GoldPrimary.copy(alpha = 0.25f) else DarkSurface)
                        .border(1.dp, if (isCurrent) GoldPrimary else BorderGlow.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .clickable {
                            currentUrl = siteUrl
                            inputUrlText = siteUrl
                            detectedStreamUrl = null
                            webViewRef?.loadUrl(siteUrl)
                        }
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isCurrent) GoldPrimary else TextSecondary
                    )
                }
            }
        }

        if (isLoading) {
            LinearProgressIndicator(
                progress = { pageLoadingProgress },
                modifier = Modifier.fillMaxWidth().height(2.dp),
                color = GoldPrimary,
                trackColor = DarkSurface
            )
        }

        // Stream Detected Banner
        if (detectedStreamUrl != null) {
            val stream = detectedStreamUrl
            if (stream != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .border(1.5.dp, GoldPrimary, RoundedCornerShape(10.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("⚡ Video-Stream erkannt", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(detectedStreamTitle.ifBlank { pageTitle }, color = TextSecondary, fontSize = 11.sp, maxLines = 1)
                        }
                        Button(
                            onClick = { onPlayDetectedStream(stream, detectedStreamTitle) },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Im Nexus Player abspielen", color = ObsidianBlack, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // WebView Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .background(ObsidianBlack)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { ctx ->
                    try {
                        WebView(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )

                            // Do NOT override layer type to avoid Samsung S25 Ultra Vulkan driver conflicts
                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                mediaPlaybackRequiresUserGesture = false
                                loadsImagesAutomatically = true
                                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                                setSupportMultipleWindows(false)
                                javaScriptCanOpenWindowsAutomatically = false
                                useWideViewPort = true
                                loadWithOverviewMode = true
                                allowFileAccess = false
                            }

                            try {
                                CookieManager.getInstance().setAcceptCookie(true)
                                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    super.onPageStarted(view, url, favicon)
                                    isLoading = true
                                    url?.let {
                                        currentUrl = it
                                        inputUrlText = it
                                    }
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    super.onPageFinished(view, url)
                                    isLoading = false
                                    url?.let {
                                        currentUrl = it
                                        inputUrlText = it
                                        pageTitle = view?.title ?: it
                                    }

                                    // Inject anti-pause JS helper to prevent 1-2s stops on web stream pages
                                    view?.evaluateJavascript(
                                        """
                                        (function() {
                                            try {
                                                // Prevent anti-ad blocker video.pause() traps
                                                if (!window.__madPatched) {
                                                    window.__madPatched = true;
                                                    var origPause = HTMLVideoElement.prototype.pause;
                                                    HTMLVideoElement.prototype.pause = function() {
                                                        if (this.currentTime > 0.5 && !this.ended && this.readyState >= 2) {
                                                            console.log("MaD TV: Ignored video.pause() timer");
                                                            return;
                                                        }
                                                        return origPause.apply(this, arguments);
                                                    };
                                                    // Block annoying ad popups that defocus video
                                                    window.open = function() { return null; };
                                                }
                                                // Ensure playsinline and autoplay
                                                var vids = document.querySelectorAll('video');
                                                for (var i = 0; i < vids.length; i++) {
                                                    vids[i].setAttribute('playsinline', 'true');
                                                    vids[i].setAttribute('webkit-playsinline', 'true');
                                                    vids[i].autoplay = true;
                                                }
                                            } catch(e) {}
                                        })();
                                        """.trimIndent(), null
                                    )
                                }

                                override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                                    view?.let {
                                        try {
                                            (it.parent as? ViewGroup)?.removeView(it)
                                            it.destroy()
                                        } catch (e: Exception) {
                                            e.printStackTrace()
                                        }
                                    }
                                    // Increment key to recreate safely without killing app
                                    webViewKey++
                                    return true
                                }

                                override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                                    val reqUrl = request?.url?.toString() ?: return super.shouldInterceptRequest(view, request)
                                    if (reqUrl.contains(".m3u8", ignoreCase = true) ||
                                        (reqUrl.contains("/live/") && reqUrl.contains(".ts"))
                                    ) {
                                        val title = view?.title ?: "Web Stream"
                                        view?.post {
                                            detectedStreamUrl = reqUrl
                                            detectedStreamTitle = title
                                        }
                                    }
                                    return super.shouldInterceptRequest(view, request)
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    pageLoadingProgress = newProgress / 100f
                                    if (newProgress == 100) isLoading = false
                                }
                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    super.onReceivedTitle(view, title)
                                    title?.let { pageTitle = it }
                                }
                            }

                            loadUrl(currentUrl)
                            webViewRef = this
                        }
                    } catch (t: Throwable) {
                        t.printStackTrace()
                        webViewError = t.localizedMessage
                        View(ctx)
                    }
                },
                update = { view ->
                    if (view is WebView) webViewRef = view
                }
            )
        }
    }
}

/**
 * Fast multi-stage asynchronous resolver to extract underlying HLS stream URLs from web TV pages
 */
private suspend fun tryResolveLiveStream(pageUrl: String): String? {
    return withContext(Dispatchers.IO) {
        try {
            val client = OkHttpClient.Builder()
                .connectTimeout(5, TimeUnit.SECONDS)
                .readTimeout(5, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()

            val request = Request.Builder()
                .url(pageUrl)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                .header("Referer", pageUrl)
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .build()

            val response = client.newCall(request).execute()
            val html = response.body?.string() ?: return@withContext null

            // 1. Direct .m3u8 regex
            val m3u8Regex = """https?://[^\s"'<>]+\.m3u8[^\s"'<>]*""".toRegex()
            val directMatch = m3u8Regex.find(html)
            if (directMatch != null) {
                return@withContext directMatch.value
            }

            // 2. Check for player iframe sources
            val iframeRegex = """<iframe[^>]+src=["'](https?://[^"']+)["']""".toRegex(RegexOption.IGNORE_CASE)
            val iframeMatch = iframeRegex.find(html)
            if (iframeMatch != null) {
                val iframeUrl = iframeMatch.groupValues[1]
                val iframeReq = Request.Builder()
                    .url(iframeUrl)
                    .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
                    .header("Referer", pageUrl)
                    .build()
                val iframeRes = client.newCall(iframeReq).execute()
                val iframeHtml = iframeRes.body?.string() ?: ""
                val nestedM3u8 = m3u8Regex.find(iframeHtml)
                if (nestedM3u8 != null) {
                    return@withContext nestedM3u8.value
                }
            }

            // 3. Check for base64 encoded stream sources (e.g., atob("..."))
            val atobRegex = """atob\(["']([A-Za-z0-9+/=]{20,})["']\)""".toRegex()
            val atobMatch = atobRegex.find(html)
            if (atobMatch != null) {
                try {
                    val decoded = String(android.util.Base64.decode(atobMatch.groupValues[1], android.util.Base64.DEFAULT))
                    val decodedM3u8 = m3u8Regex.find(decoded)
                    if (decodedM3u8 != null) {
                        return@withContext decodedM3u8.value
                    }
                } catch (e: Exception) {
                    // Ignore decoding errors
                }
            }

            null
        } catch (e: Exception) {
            null
        }
    }
}
