package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab

/**
 * Schlanke, platzsparende Navigations-Seitenleiste für Android TV und Querformat / Tablets.
 * Ersetzt die starre Fußleiste, sodass die gesamte vertikale Bildschirmhöhe für die TV-Sender
 * und Videos zur Verfügung steht. Vollständig bedienbar mit TV-Fernbedienung (D-Pad).
 */
@Composable
fun TvNavigationRail(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    liveCount: Int,
    radioCount: Int = 0,
    movieCount: Int,
    seriesCount: Int,
    isEnglish: Boolean = false,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .width(74.dp)
            .fillMaxHeight(),
        color = ObsidianBlack,
        tonalElevation = 6.dp,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = BorderGlow.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .statusBarsPadding()
                .padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Oberer Bereich: App Logo & Version V.5.0
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.Black)
                        .border(1.dp, GoldPrimary, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.app_logo),
                        contentDescription = "MaD Internet TV V.5.0 final",
                        modifier = Modifier.size(34.dp)
                    )
                }
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "MaD V.5.0 final",
                    color = GoldPrimary,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 0.3.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Mittlerer Bereich: Navigations-Schaltflächen
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .weight(1f, fill = false)
                    .verticalScroll(rememberScrollState())
            ) {
                // 1. Live TV
                TvNavRailItem(
                    icon = Icons.Default.Tv,
                    label = if (isEnglish) "Live TV" else "Live TV",
                    count = liveCount,
                    isSelected = selectedTab == MainTab.LIVE_TV,
                    badgeColor = AccentEmerald,
                    testTag = "tv_rail_livetv",
                    onClick = { onTabSelected(MainTab.LIVE_TV) }
                )

                // 2. Radio
                if (radioCount > 0) {
                    TvNavRailItem(
                        icon = Icons.Default.Radio,
                        label = if (isEnglish) "Radio" else "Radio",
                        count = radioCount,
                        isSelected = selectedTab == MainTab.RADIO,
                        badgeColor = AccentCyan,
                        testTag = "tv_rail_radio",
                        onClick = { onTabSelected(MainTab.RADIO) }
                    )
                }

                // 3. Filme
                TvNavRailItem(
                    icon = Icons.Default.Movie,
                    label = if (isEnglish) "Movies" else "Filme",
                    count = movieCount,
                    isSelected = selectedTab == MainTab.MOVIES,
                    badgeColor = AccentCyan,
                    testTag = "tv_rail_movies",
                    onClick = { onTabSelected(MainTab.MOVIES) }
                )

                // 4. Serien
                TvNavRailItem(
                    icon = Icons.Default.VideoLibrary,
                    label = if (isEnglish) "Series" else "Serien",
                    count = seriesCount,
                    isSelected = selectedTab == MainTab.SERIES,
                    badgeColor = GoldLight,
                    testTag = "tv_rail_series",
                    onClick = { onTabSelected(MainTab.SERIES) }
                )

                // 5. Live TV light (Deutsche Live-Streams direkt im Player)
                TvNavRailItem(
                    icon = Icons.Default.Tv,
                    label = "Live TV light",
                    count = null,
                    isSelected = selectedTab == MainTab.LIVE_TV_LIGHT,
                    badgeColor = AccentEmerald,
                    testTag = "tv_rail_livetv_light",
                    onClick = { onTabSelected(MainTab.LIVE_TV_LIGHT) }
                )

                // 6. Suche
                TvNavRailItem(
                    icon = Icons.Default.Search,
                    label = if (isEnglish) "Search" else "Suche",
                    count = null,
                    isSelected = selectedTab == MainTab.SEARCH,
                    badgeColor = GoldLight,
                    testTag = "tv_rail_search",
                    onClick = { onTabSelected(MainTab.SEARCH) }
                )

                // 6. Favoriten
                TvNavRailItem(
                    icon = Icons.Default.Star,
                    label = if (isEnglish) "Favorites" else "Favoriten",
                    count = null,
                    isSelected = selectedTab == MainTab.FAVORITES,
                    badgeColor = GoldPrimary,
                    testTag = "tv_rail_favorites",
                    onClick = { onTabSelected(MainTab.FAVORITES) }
                )

                // 7. Weiter ansehen
                TvNavRailItem(
                    icon = Icons.Default.PlayArrow,
                    label = if (isEnglish) "Resume" else "Fortsetzen",
                    count = null,
                    isSelected = selectedTab == MainTab.CONTINUE_WATCHING,
                    badgeColor = AccentEmerald,
                    testTag = "tv_rail_continue",
                    onClick = { onTabSelected(MainTab.CONTINUE_WATCHING) }
                )

                // 8. Web Streams
                TvNavRailItem(
                    icon = Icons.Default.Language,
                    label = if (isEnglish) "Web TV" else "Web TV",
                    count = null,
                    isSelected = selectedTab == MainTab.WEB_STREAMS,
                    badgeColor = AccentCyan,
                    testTag = "tv_rail_webstreams",
                    onClick = { onTabSelected(MainTab.WEB_STREAMS) }
                )

                // 9. EPG Programmzeitschrift
                TvNavRailItem(
                    icon = Icons.Default.CalendarMonth,
                    label = "EPG",
                    count = null,
                    isSelected = selectedTab == MainTab.EPG_GUIDE,
                    badgeColor = GoldPrimary,
                    testTag = "tv_rail_epg",
                    onClick = { onTabSelected(MainTab.EPG_GUIDE) }
                )
            }

            // Unterer Bereich: Einstellungen
            TvNavRailItem(
                icon = Icons.Default.Settings,
                label = if (isEnglish) "Settings" else "Einstellungen",
                count = null,
                isSelected = selectedTab == MainTab.SETTINGS,
                badgeColor = GoldPrimary,
                testTag = "tv_rail_settings",
                onClick = { onTabSelected(MainTab.SETTINGS) }
            )
        }
    }
}

@Composable
private fun TvNavRailItem(
    icon: ImageVector,
    label: String,
    count: Int?,
    isSelected: Boolean,
    badgeColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused by interactionSource.collectIsFocusedAsState()

    val containerBg = when {
        isFocused -> GoldPrimary.copy(alpha = 0.25f)
        isSelected -> DarkSurfaceElevated
        else -> Color.Transparent
    }

    val borderColor = when {
        isFocused -> GoldPrimary
        isSelected -> GoldPrimary.copy(alpha = 0.7f)
        else -> Color.Transparent
    }

    val iconTint = when {
        isFocused -> GoldLight
        isSelected -> GoldPrimary
        else -> TextSecondary
    }

    val textColor = when {
        isFocused -> GoldLight
        isSelected -> GoldPrimary
        else -> TextMuted
    }

    Box(
        modifier = Modifier
            .width(66.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(containerBg)
            .border(
                width = if (isFocused) 2.dp else if (isSelected) 1.dp else 0.dp,
                color = borderColor,
                shape = RoundedCornerShape(12.dp)
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .focusable(interactionSource = interactionSource)
            .padding(vertical = 6.dp, horizontal = 2.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )

                if (count != null && count > 0) {
                    Box(
                        modifier = Modifier
                            .padding(start = 12.dp, bottom = 4.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(badgeColor)
                            .padding(horizontal = 3.dp, vertical = 0.5.dp)
                    ) {
                        Text(
                            text = if (count > 999) "${count / 1000}k" else "$count",
                            color = Color.Black,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = label,
                fontSize = 9.5.sp,
                fontWeight = if (isSelected || isFocused) FontWeight.Bold else FontWeight.Medium,
                color = textColor,
                maxLines = 1,
                textAlign = TextAlign.Center
            )
        }
    }
}
