package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// MaD Internet TV - Luxury Obsidian & Gold Color Palette
val ObsidianBlack = Color(0xFF0A0E17)
val DarkNavyBackground = Color(0xFF0A0E17)
val DarkNavyCard = Color(0xFF131B2B)
val DarkCardBackground = Color(0xFF131B2B)
val DarkSurface = Color(0xFF182236)
val DarkSurfaceElevated = Color(0xFF1F2D47)

// Premium Gold Accents (Crown & Brand)
val GoldLight = Color(0xFFFFE082)
val GoldPrimary = Color(0xFFFFD700)
val GoldDark = Color(0xFFFFA000)
val GoldMuted = Color(0x33FFD700)

// Accents & DACH Colors
val AccentCyan = Color(0xFF38BDF8)
val AccentEmerald = Color(0xFF10B981)
val AccentRose = Color(0xFFF43F5E)
val AccentPurple = Color(0xFFA855F7)
val AccentAmber = Color(0xFFF59E0B)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Border & Divider
val BorderGlow = Color(0x33FFD700)
val BorderSubtle = Color(0x22FFFFFF)
