package com.example.ui.components

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SmartDisplay
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.data.model.ChannelItem
import com.example.data.model.ContentType
import com.example.data.model.PlayerEngine
import com.example.data.player.PlayerManager
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkNavyBackground
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

data class LiveTvLightChannel(
    val id: String,
    val name: String,
    val category: String,
    val logoUrl: String,
    val logoBadge: String,
    val brandColor: Color,
    val primaryStreamUrl: String,
    val fallbackStreamUrls: List<String> = emptyList(),
    val internalResolverKey: String = "",
    val tvgId: String = ""
) {
    fun toChannelItem(resolvedUrl: String = primaryStreamUrl): ChannelItem {
        return ChannelItem(
            id = "ltv_light_$id",
            playlistId = LIVE_TV_LIGHT_PLAYLIST_ID,
            name = name,
            streamUrl = resolvedUrl,
            logoUrl = logoUrl,
            groupTitle = category,
            type = ContentType.LIVE_TV,
            tvgId = tvgId,
            countryCode = "DE"
        )
    }
}

const val LIVE_TV_LIGHT_PLAYLIST_ID = "live_tv_light"

object LiveTvLightCatalog {

    private const val LOGO_BASE = "https://raw.githubusercontent.com/tv-logo/tv-logos/main/countries/germany"

    val germanChannels: List<LiveTvLightChannel> = listOf(
        // 1. Öffentlich-Rechtlich
        LiveTvLightChannel(
            id = "das_erste",
            name = "Das Erste HD",
            category = "Öffentlich-Rechtlich",
            logoUrl = "$LOGO_BASE/das-erste-de.png",
            logoBadge = "ARD",
            brandColor = Color(0xFF00519E),
            primaryStreamUrl = "https://mcdn.daserste.de/daserste/de/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/ardX/tracks-v1a1/mono.ts.m3u8",
                "https://s6.hopslan.com/ardX/index.m3u8",
                "https://derste247livede.akamaized.net/hls/live/658317/daserste_de/master.m3u8"
            ),
            internalResolverKey = "ard-de",
            tvgId = "DasErste.de"
        ),
        LiveTvLightChannel(
            id = "zdf",
            name = "ZDF HD",
            category = "Öffentlich-Rechtlich",
            logoUrl = "$LOGO_BASE/zdf-de.png",
            logoBadge = "ZDF",
            brandColor = Color(0xFFFA7D19),
            primaryStreamUrl = "https://zdf-hls-15.akamaized.net/hls/live/2016498/de/veryhigh/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/zdfX1/tracks-v1a1/mono.ts.m3u8",
                "https://s6.hopslan.com/zdfX1/index.m3u8",
                "https://zdf-hls-15.akamaized.net/hls/live/2016498/de/high/master.m3u8"
            ),
            internalResolverKey = "zdf-de",
            tvgId = "ZDF.de"
        ),
        LiveTvLightChannel(
            id = "zdf_neo",
            name = "ZDFneo HD",
            category = "Öffentlich-Rechtlich",
            logoUrl = "$LOGO_BASE/zdf-neo-de.png",
            logoBadge = "neo",
            brandColor = Color(0xFF009B72),
            primaryStreamUrl = "https://zdf-hls-16.akamaized.net/hls/live/2016499/de/veryhigh/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/zdfneoX/tracks-v1a1/mono.ts.m3u8",
                "https://s6.hopslan.com/zdfneoX/index.m3u8"
            ),
            internalResolverKey = "zdfneo",
            tvgId = "ZDFneo.de"
        ),
        LiveTvLightChannel(
            id = "one",
            name = "ONE HD",
            category = "Öffentlich-Rechtlich",
            logoUrl = "$LOGO_BASE/one-de.png",
            logoBadge = "ONE",
            brandColor = Color(0xFF7B2CBF),
            primaryStreamUrl = "https://mcdn.one.ard.de/ardone/hls/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/onetv/tracks-v1a1/mono.ts.m3u8",
                "https://s6.hopslan.com/onetv/index.m3u8"
            ),
            internalResolverKey = "one-tv",
            tvgId = "ONE.de"
        ),

        // 2. Privatsender (Direkte muxed HLS-Streams & exakte 2ix2-Slugs)
        LiveTvLightChannel(
            id = "rtl",
            name = "RTL",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/rtl-de.png",
            logoBadge = "RTL",
            brandColor = Color(0xFFE30613),
            primaryStreamUrl = "https://s6.hopslan.com/rtlt11/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/rtlt11/index.m3u8",
                "https://s1.hopslan.com/rtl/index.m3u8"
            ),
            internalResolverKey = "rtl-live",
            tvgId = "RTL.de"
        ),
        LiveTvLightChannel(
            id = "prosieben",
            name = "ProSieben",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/prosieben-de.png",
            logoBadge = "PRO7",
            brandColor = Color(0xFFE60000),
            primaryStreamUrl = "https://s6.hopslan.com/pro7z/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/pro7z/index.m3u8"
            ),
            internalResolverKey = "pro7",
            tvgId = "ProSieben.de"
        ),
        LiveTvLightChannel(
            id = "sat1",
            name = "SAT.1",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/sat-1-de.png",
            logoBadge = "SAT.1",
            brandColor = Color(0xFF009FE3),
            primaryStreamUrl = "https://s6.hopslan.com/sat1z/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/sat1z/index.m3u8"
            ),
            internalResolverKey = "sat-1",
            tvgId = "Sat1.de"
        ),
        LiveTvLightChannel(
            id = "vox",
            name = "VOX",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/vox-de.png",
            logoBadge = "VOX",
            brandColor = Color(0xFFC8102E),
            primaryStreamUrl = "https://s6.hopslan.com/voxz/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/voxz/index.m3u8"
            ),
            internalResolverKey = "vox",
            tvgId = "VOX.de"
        ),
        LiveTvLightChannel(
            id = "kabel_eins",
            name = "Kabel Eins",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/kabel-eins-de.png",
            logoBadge = "K1",
            brandColor = Color(0xFFFF6600),
            primaryStreamUrl = "https://s6.hopslan.com/kabel1z/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/kabel1z/index.m3u8"
            ),
            internalResolverKey = "kabel-1",
            tvgId = "KabelEins.de"
        ),
        LiveTvLightChannel(
            id = "rtl2",
            name = "RTL II",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/rtl-zwei-de.png",
            logoBadge = "RTL2",
            brandColor = Color(0xFF00A8E8),
            primaryStreamUrl = "https://s6.hopslan.com/rtl2q/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/rtl2q/index.m3u8"
            ),
            internalResolverKey = "rtl2-live",
            tvgId = "RTL2.de"
        ),
        LiveTvLightChannel(
            id = "super_rtl",
            name = "Super RTL",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/super-rtl-de.png",
            logoBadge = "SRTL",
            brandColor = Color(0xFFFF4500),
            primaryStreamUrl = "https://s6.hopslan.com/superX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/superX/index.m3u8"
            ),
            internalResolverKey = "super-rtl-live",
            tvgId = "SuperRTL.de"
        ),
        LiveTvLightChannel(
            id = "nitro",
            name = "NITRO",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/nitro-de.png",
            logoBadge = "NITRO",
            brandColor = Color(0xFFFF5500),
            primaryStreamUrl = "https://s6.hopslan.com/nitro1/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/nitro1/index.m3u8"
            ),
            internalResolverKey = "rtl-nitro-tv",
            tvgId = "NITRO.de"
        ),
        LiveTvLightChannel(
            id = "dmax",
            name = "DMAX",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/dmax-de.png",
            logoBadge = "DMAX",
            brandColor = Color(0xFFFF8800),
            primaryStreamUrl = "https://s6.hopslan.com/dmaxX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/dmaxX/index.m3u8"
            ),
            internalResolverKey = "dmax",
            tvgId = "DMAX.de"
        ),
        LiveTvLightChannel(
            id = "prosieben_maxx",
            name = "ProSieben MAXX",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/prosieben-maxx-de.png",
            logoBadge = "MAXX",
            brandColor = Color(0xFF1E3A8A),
            primaryStreamUrl = "https://s6.hopslan.com/pro7maxxX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/pro7maxxX/index.m3u8"
            ),
            internalResolverKey = "prosieben-maxx-tv",
            tvgId = "ProSiebenMaxx.de"
        ),
        LiveTvLightChannel(
            id = "sat1_gold",
            name = "SAT.1 Gold",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/sat-1-gold-de.png",
            logoBadge = "GOLD",
            brandColor = Color(0xFFD97706),
            primaryStreamUrl = "https://s6.hopslan.com/goldX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/goldX/index.m3u8"
            ),
            internalResolverKey = "sat1-gold",
            tvgId = "Sat1Gold.de"
        ),
        LiveTvLightChannel(
            id = "sixx",
            name = "sixx",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/sixx-de.png",
            logoBadge = "SIXX",
            brandColor = Color(0xFF84CC16),
            primaryStreamUrl = "https://s6.hopslan.com/sixX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/sixX/index.m3u8"
            ),
            internalResolverKey = "sixx",
            tvgId = "sixx.de"
        ),
        LiveTvLightChannel(
            id = "tele5",
            name = "TELE 5",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/tele-5-de.png",
            logoBadge = "T5",
            brandColor = Color(0xFF9333EA),
            primaryStreamUrl = "https://s6.hopslan.com/tele5X/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/tele5X/index.m3u8"
            ),
            internalResolverKey = "tele-5",
            tvgId = "Tele5.de"
        ),
        LiveTvLightChannel(
            id = "tlc",
            name = "TLC Deutschland",
            category = "Privatsender",
            logoUrl = "$LOGO_BASE/tlc-de.png",
            logoBadge = "TLC",
            brandColor = Color(0xFFEC4899),
            primaryStreamUrl = "https://s6.hopslan.com/tlcX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/tlcX/index.m3u8"
            ),
            internalResolverKey = "tlc",
            tvgId = "TLC.de"
        ),

        // 3. Nachrichten & Info
        LiveTvLightChannel(
            id = "tagesschau24",
            name = "tagesschau24 HD",
            category = "Nachrichten & Info",
            logoUrl = "$LOGO_BASE/tagesschau24-de.png",
            logoBadge = "TS24",
            brandColor = Color(0xFF003B7E),
            primaryStreamUrl = "https://tagesschau.akamaized.net/hls/live/2020115/tagesschau/tagesschau_1/master.m3u8",
            internalResolverKey = "tagesschau",
            tvgId = "tagesschau24.de"
        ),
        LiveTvLightChannel(
            id = "welt",
            name = "WELT",
            category = "Nachrichten & Info",
            logoUrl = "$LOGO_BASE/welt-de.png",
            logoBadge = "WELT",
            brandColor = Color(0xFF004B87),
            primaryStreamUrl = "https://live2.welt.de/live2/hls/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/n24X/tracks-v1a1/mono.ts.m3u8",
                "https://s6.hopslan.com/n24X/index.m3u8"
            ),
            internalResolverKey = "welt",
            tvgId = "WELT.de"
        ),
        LiveTvLightChannel(
            id = "ntv",
            name = "n-tv",
            category = "Nachrichten & Info",
            logoUrl = "$LOGO_BASE/n-tv-de.png",
            logoBadge = "n-tv",
            brandColor = Color(0xFFB91C1C),
            primaryStreamUrl = "https://s6.hopslan.com/ntvX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/ntvX/index.m3u8"
            ),
            internalResolverKey = "n-tv-live",
            tvgId = "ntv.de"
        ),
        LiveTvLightChannel(
            id = "phoenix",
            name = "PHOENIX HD",
            category = "Nachrichten & Info",
            logoUrl = "$LOGO_BASE/phoenix-de.png",
            logoBadge = "PHX",
            brandColor = Color(0xFF0284C7),
            primaryStreamUrl = "https://zdf-hls-19.akamaized.net/hls/live/2016502/de/veryhigh/master.m3u8",
            internalResolverKey = "phoenix",
            tvgId = "Phoenix.de"
        ),
        LiveTvLightChannel(
            id = "dw_deutsch",
            name = "DW Deutsch HD",
            category = "Nachrichten & Info",
            logoUrl = "$LOGO_BASE/dw-de.png",
            logoBadge = "DW",
            brandColor = Color(0xFF0066B3),
            primaryStreamUrl = "https://dwamdstream104.akamaized.net/hls/live/2015530/dwstream104/index.m3u8",
            internalResolverKey = "deutsche-welle",
            tvgId = "DW.de"
        ),

        // 4. Doku & Kultur
        LiveTvLightChannel(
            id = "arte",
            name = "ARTE Deutsch HD",
            category = "Doku & Kultur",
            logoUrl = "$LOGO_BASE/arte-de.png",
            logoBadge = "ARTE",
            brandColor = Color(0xFFFA481C),
            primaryStreamUrl = "https://artesimulcast.akamaized.net/hls/live/2031003/artelive_de/master.m3u8",
            internalResolverKey = "arte",
            tvgId = "ARTE.de"
        ),
        LiveTvLightChannel(
            id = "3sat",
            name = "3sat HD",
            category = "Doku & Kultur",
            logoUrl = "$LOGO_BASE/3sat-de.png",
            logoBadge = "3sat",
            brandColor = Color(0xFFDC2626),
            primaryStreamUrl = "https://zdf-hls-18.akamaized.net/hls/live/2016501/de/veryhigh/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/3sat/tracks-v1a1/mono.ts.m3u8",
                "https://s6.hopslan.com/3sat/index.m3u8"
            ),
            internalResolverKey = "3sat",
            tvgId = "3sat.de"
        ),
        LiveTvLightChannel(
            id = "zdf_info",
            name = "ZDFinfo HD",
            category = "Doku & Kultur",
            logoUrl = "$LOGO_BASE/zdf-info-de.png",
            logoBadge = "info",
            brandColor = Color(0xFF0369A1),
            primaryStreamUrl = "https://zdf-hls-17.akamaized.net/hls/live/2016500/de/veryhigh/master.m3u8",
            internalResolverKey = "zdfinfo",
            tvgId = "ZDFinfo.de"
        ),
        LiveTvLightChannel(
            id = "ard_alpha",
            name = "ARD-alpha HD",
            category = "Doku & Kultur",
            logoUrl = "$LOGO_BASE/ard-alpha-de.png",
            logoBadge = "alpha",
            brandColor = Color(0xFF1D4ED8),
            primaryStreamUrl = "https://mcdn.br.de/br/fs/ard_alpha/hls/de/master.m3u8",
            internalResolverKey = "ard-alpha-live-stream",
            tvgId = "ARDalpha.de"
        ),
        LiveTvLightChannel(
            id = "kabel_eins_doku",
            name = "Kabel Eins Doku",
            category = "Doku & Kultur",
            logoUrl = "$LOGO_BASE/kabel-eins-doku-de.png",
            logoBadge = "K1D",
            brandColor = Color(0xFFB45309),
            primaryStreamUrl = "https://s6.hopslan.com/dokuX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/dokuX/index.m3u8"
            ),
            internalResolverKey = "kabel-1-doku",
            tvgId = "KabelEinsDoku.de"
        ),
        LiveTvLightChannel(
            id = "n24_doku",
            name = "N24 Doku",
            category = "Doku & Kultur",
            logoUrl = "$LOGO_BASE/n24-doku-de.png",
            logoBadge = "N24D",
            brandColor = Color(0xFF0F766E),
            primaryStreamUrl = "https://s6.hopslan.com/n24X/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://live2.welt.de/live2/hls/master.m3u8"
            ),
            internalResolverKey = "welt",
            tvgId = "N24Doku.de"
        ),

        // 5. Sport & Musik
        LiveTvLightChannel(
            id = "sport1",
            name = "SPORT1",
            category = "Sport & Musik",
            logoUrl = "$LOGO_BASE/sport1-de.png",
            logoBadge = "SP1",
            brandColor = Color(0xFFEAB308),
            primaryStreamUrl = "https://s1.hopslan.com/rtl/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s1.hopslan.com/rtl/index.m3u8"
            ),
            internalResolverKey = "sport1",
            tvgId = "Sport1.de"
        ),
        LiveTvLightChannel(
            id = "deluxe_music",
            name = "DELUXE MUSIC",
            category = "Sport & Musik",
            logoUrl = "$LOGO_BASE/deluxe-music-de.png",
            logoBadge = "DLX",
            brandColor = Color(0xFFBE123C),
            primaryStreamUrl = "https://sdn-global-live-streaming-packager-cache.3qsdn.com/13456/13456_264_live.m3u8",
            internalResolverKey = "deluxe-music-live-stream",
            tvgId = "DeluxeMusic.de"
        ),
        LiveTvLightChannel(
            id = "comedy_central",
            name = "Comedy Central",
            category = "Sport & Musik",
            logoUrl = "$LOGO_BASE/comedy-central-de.png",
            logoBadge = "CC",
            brandColor = Color(0xFFD97706),
            primaryStreamUrl = "https://s6.hopslan.com/vivaX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/vivaX/index.m3u8"
            ),
            internalResolverKey = "comedy-central",
            tvgId = "ComedyCentral.de"
        ),

        // 6. Kinder & Familie
        LiveTvLightChannel(
            id = "kika",
            name = "KiKA HD",
            category = "Kinder & Familie",
            logoUrl = "$LOGO_BASE/kika-de.png",
            logoBadge = "KiKA",
            brandColor = Color(0xFF16A34A),
            primaryStreamUrl = "https://kika-hls.akamaized.net/hls/live/2022693/live/master.m3u8",
            internalResolverKey = "kika",
            tvgId = "KiKA.de"
        ),
        LiveTvLightChannel(
            id = "disney_channel",
            name = "Disney Channel",
            category = "Kinder & Familie",
            logoUrl = "$LOGO_BASE/disney-channel-de.png",
            logoBadge = "DISNEY",
            brandColor = Color(0xFF2563EB),
            primaryStreamUrl = "https://s6.hopslan.com/disneyX/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s6.hopslan.com/disneyX/index.m3u8"
            ),
            internalResolverKey = "disney-channel",
            tvgId = "DisneyChannel.de"
        ),

        // 7. Regional (Dritte Programme)
        LiveTvLightChannel(
            id = "wdr",
            name = "WDR HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/wdr-de.png",
            logoBadge = "WDR",
            brandColor = Color(0xFF003865),
            primaryStreamUrl = "https://wdrfsgeo.akamaized.net/hls/live/2015750/wdrfsgeo/master.m3u8",
            internalResolverKey = "wdr-fernsehen",
            tvgId = "WDR.de"
        ),
        LiveTvLightChannel(
            id = "ndr",
            name = "NDR HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/ndr-de.png",
            logoBadge = "NDR",
            brandColor = Color(0xFF003D7A),
            primaryStreamUrl = "https://mcdn.ndr.de/ndr/hls/ndr_fs/ndr_nds/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://ndrfs-lh.akamaihd.net/i/ndrfs_nds@430233/master.m3u8"
            ),
            internalResolverKey = "ndr-fernsehen",
            tvgId = "NDR.de"
        ),
        LiveTvLightChannel(
            id = "swr",
            name = "SWR HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/swr-de.png",
            logoBadge = "SWR",
            brandColor = Color(0xFF0F172A),
            primaryStreamUrl = "https://swrbw-hls.akamaized.net/hls/live/2018674/swrbw/master.m3u8",
            internalResolverKey = "swr-fernsehen",
            tvgId = "SWR.de"
        ),
        LiveTvLightChannel(
            id = "br",
            name = "BR Fernsehen HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/br-de.png",
            logoBadge = "BR",
            brandColor = Color(0xFF0066CC),
            primaryStreamUrl = "https://mcdn.br.de/br/fs/bfs_sued/hls/de/master.m3u8",
            fallbackStreamUrls = listOf(
                "https://brfs-lh.akamaihd.net/i/brfs_sued@119890/master.m3u8"
            ),
            internalResolverKey = "br-fernsehen",
            tvgId = "BR.de"
        ),
        LiveTvLightChannel(
            id = "mdr",
            name = "MDR HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/mdr-de.png",
            logoBadge = "MDR",
            brandColor = Color(0xFF0055A5),
            primaryStreamUrl = "https://mdrtvsnhls.akamaized.net/hls/live/2016928/mdrtvsn/master.m3u8",
            internalResolverKey = "mdr-fernsehen",
            tvgId = "MDR.de"
        ),
        LiveTvLightChannel(
            id = "hr",
            name = "hr-fernsehen HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/hr-de.png",
            logoBadge = "HR",
            brandColor = Color(0xFF004C97),
            primaryStreamUrl = "https://hrhls.akamaized.net/hls/live/2024525/hrhls/master.m3u8",
            internalResolverKey = "hr-fernsehen",
            tvgId = "HR.de"
        ),
        LiveTvLightChannel(
            id = "rbb",
            name = "rbb Fernsehen HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/rbb-de.png",
            logoBadge = "rbb",
            brandColor = Color(0xFFD90429),
            primaryStreamUrl = "https://rbb-hls-berlin.akamaized.net/hls/live/2017824/rbb_berlin/master.m3u8",
            internalResolverKey = "rbb-fernsehen",
            tvgId = "RBB.de"
        ),
        LiveTvLightChannel(
            id = "sr",
            name = "SR Fernsehen HD",
            category = "Drittes Programm",
            logoUrl = "$LOGO_BASE/sr-de.png",
            logoBadge = "SR",
            brandColor = Color(0xFF00519E),
            primaryStreamUrl = "https://srfshls.akamaized.net/hls/live/2020118/srfs/master.m3u8",
            internalResolverKey = "sr-fernsehen",
            tvgId = "SR.de"
        ),
        LiveTvLightChannel(
            id = "alex_berlin",
            name = "ALEX Berlin",
            category = "Drittes Programm",
            logoUrl = "https://www.2ix2.com/wp-content/uploads/2021/06/44.png",
            logoBadge = "ALEX",
            brandColor = Color(0xFF009688),
            primaryStreamUrl = "https://s4.hopslan.com/alex/tracks-v1a1/mono.ts.m3u8",
            fallbackStreamUrls = listOf(
                "https://s4.hopslan.com/alex/index.m3u8"
            ),
            internalResolverKey = "alex-berlin",
            tvgId = "ALEXBerlin.de"
        )
    )

    fun asChannelItems(): List<ChannelItem> {
        return germanChannels.map { ch ->
            val cachedUrl = LiveTvLightStreamResolver.getCachedStreamUrl(ch.id) ?: ch.primaryStreamUrl
            ch.toChannelItem(cachedUrl)
        }
    }
}

/**
 * Stiller Hintergrund-Resolver für Live TV light:
 * Extrahiert bei Bedarf dynamische HLS (.m3u8) Stream-Tokens im Hintergrund (ohne Browser-Anzeige
 * und ohne Herkunftshinweise), sodass jeder Sender direkt im Nexus Player, VLC oder MX Player läuft.
 */
object LiveTvLightStreamResolver {

    private val resolvedCache = ConcurrentHashMap<String, Pair<String, Long>>()
    private const val CACHE_TTL_MS = 20 * 60 * 1000L // 20 Minuten Token-Gültigkeit

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    fun getCachedStreamUrl(channelId: String): String? {
        val entry = resolvedCache[channelId] ?: return null
        if (System.currentTimeMillis() - entry.second < CACHE_TTL_MS) {
            return entry.first
        }
        resolvedCache.remove(channelId)
        return null
    }

    suspend fun resolvePlayableStream(context: Context, channel: LiveTvLightChannel): String {
        getCachedStreamUrl(channel.id)?.let { return it }

        return withContext(Dispatchers.IO) {
            // 1. Prüfe direkte Erreichbarkeit des konfigurierten Primär-Streams (inkl. hopslan.com & ARD/ZDF/Akamai CDN)
            if (verifyHlsReachable(channel.primaryStreamUrl)) {
                val optimized = upgradeToDirectMuxedVariant(channel.primaryStreamUrl)
                resolvedCache[channel.id] = optimized to System.currentTimeMillis()
                return@withContext optimized
            }

            // 2. Falls Server-Subdomain oder Stream-Pfad auf 2ix2.com gewechselt hat, löse aktuellen .m3u8 Link lautlos auf
            if (channel.internalResolverKey.isNotBlank()) {
                val targetPage = "https://www.2ix2.com/${channel.internalResolverKey.trim('/')}/"
                val extractedHttp = extractM3u8ViaHttp(targetPage)
                if (!extractedHttp.isNullOrBlank()) {
                    val optimized = upgradeToDirectMuxedVariant(extractedHttp)
                    resolvedCache[channel.id] = optimized to System.currentTimeMillis()
                    return@withContext optimized
                }

                // 3. Lautloser Headless-Extractor für JS-generierte .m3u8 Tokens (unsichtbar im Hintergrund)
                val extractedHeadless = extractM3u8ViaHeadlessInterceptor(context, targetPage)
                if (!extractedHeadless.isNullOrBlank()) {
                    val optimized = upgradeToDirectMuxedVariant(extractedHeadless)
                    resolvedCache[channel.id] = optimized to System.currentTimeMillis()
                    return@withContext optimized
                }
            }

            // 4. Prüfe hinterlegte Fallback-Streams
            for (fallback in channel.fallbackStreamUrls) {
                if (verifyHlsReachable(fallback)) {
                    val optimized = upgradeToDirectMuxedVariant(fallback)
                    resolvedCache[channel.id] = optimized to System.currentTimeMillis()
                    return@withContext optimized
                }
            }

            channel.primaryStreamUrl
        }
    }

    /**
     * Für hopslan.com Streams: Nutzt direkt die gemuxte Video+Audio-Variante (tracks-v1a1/mono.ts.m3u8),
     * um parallele WebVTT-Untertitel-Requests auf abgelaufene Segmente zu vermeiden.
     */
    private fun upgradeToDirectMuxedVariant(url: String): String {
        if (url.contains("hopslan.com", ignoreCase = true) && url.endsWith("/index.m3u8", ignoreCase = true)) {
            val muxedCandidate = url.substringBeforeLast("/index.m3u8") + "/tracks-v1a1/mono.ts.m3u8"
            if (verifyHlsReachable(muxedCandidate)) {
                return muxedCandidate
            }
        }
        return url
    }

    private fun verifyHlsReachable(url: String): Boolean {
        return try {
            val reqBuilder = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
            if (url.contains("hopslan.com", ignoreCase = true) || url.contains("2ix2.com", ignoreCase = true)) {
                reqBuilder.header("Referer", "https://www.2ix2.com/")
                reqBuilder.header("Origin", "https://www.2ix2.com")
            }
            httpClient.newCall(reqBuilder.build()).execute().use { res ->
                res.isSuccessful
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun extractM3u8ViaHttp(pageUrl: String): String? {
        return try {
            val ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            val req = Request.Builder()
                .url(pageUrl)
                .header("User-Agent", ua)
                .header("Referer", "https://www.2ix2.com/")
                .build()

            val html = httpClient.newCall(req).execute().use { it.body?.string() } ?: return null
            findM3u8InHtml(html)?.let { return it }

            // Prüfe eingebettete Player-Iframes
            val iframeRegex = """<iframe[^>]+src=["'](https?://[^"']+)["']""".toRegex(RegexOption.IGNORE_CASE)
            for (match in iframeRegex.findAll(html)) {
                val iframeUrl = match.groupValues[1]
                if (iframeUrl.contains("google") || iframeUrl.contains("facebook") || iframeUrl.contains("ads")) continue
                val iframeReq = Request.Builder()
                    .url(iframeUrl)
                    .header("User-Agent", ua)
                    .header("Referer", pageUrl)
                    .build()
                val iframeHtml = httpClient.newCall(iframeReq).execute().use { it.body?.string() } ?: continue
                findM3u8InHtml(iframeHtml)?.let { return it }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun findM3u8InHtml(content: String): String? {
        val unescaped = content.replace("\\/", "/")
        val m3u8Regex = """https?://[^\s"'<>\\]+\.m3u8[^\s"'<>\\]*""".toRegex(RegexOption.IGNORE_CASE)
        m3u8Regex.find(unescaped)?.value?.let { return it }

        val atobRegex = """atob\(["']([A-Za-z0-9+/=]{20,})["']\)""".toRegex()
        for (match in atobRegex.findAll(unescaped)) {
            try {
                val decoded = String(android.util.Base64.decode(match.groupValues[1], android.util.Base64.DEFAULT))
                m3u8Regex.find(decoded)?.value?.let { return it }
            } catch (_: Exception) {}
        }
        return null
    }

    @SuppressLint("SetJavaScriptEnabled")
    private suspend fun extractM3u8ViaHeadlessInterceptor(context: Context, pageUrl: String): String? {
        return withTimeoutOrNull(3200L) {
            withContext(Dispatchers.Main) {
                suspendCancellableCoroutine { cont ->
                    var webView: WebView? = null
                    var completed = false

                    fun finish(result: String?) {
                        if (!completed) {
                            completed = true
                            try {
                                webView?.stopLoading()
                                webView?.destroy()
                            } catch (_: Exception) {}
                            webView = null
                            if (cont.isActive) {
                                cont.resume(result)
                            }
                        }
                    }

                    try {
                        val wv = WebView(context.applicationContext).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                            settings.userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

                            try {
                                CookieManager.getInstance().setAcceptCookie(true)
                                CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                            } catch (_: Exception) {}

                            webViewClient = object : WebViewClient() {
                                override fun shouldInterceptRequest(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): WebResourceResponse? {
                                    val reqUrl = request?.url?.toString() ?: return super.shouldInterceptRequest(view, request)
                                    if (reqUrl.contains(".m3u8", ignoreCase = true)) {
                                        view?.post { finish(reqUrl) }
                                    }
                                    return super.shouldInterceptRequest(view, request)
                                }
                            }
                        }
                        webView = wv
                        cont.invokeOnCancellation {
                            try {
                                wv.stopLoading()
                                wv.destroy()
                            } catch (_: Exception) {}
                        }
                        wv.loadUrl(pageUrl, mapOf("Referer" to "https://www.2ix2.com/"))
                    } catch (_: Throwable) {
                        finish(null)
                    }
                }
            }
        }
    }
}

/**
 * Rubrik "Live TV light" (rechts neben Serien):
 * Zeigt ausschließlich die deutschen Live-TV-Sender einzeln mit Senderlogo an
 * und spielt diese direkt im Nexus Player, VLC oder einem externen Player ab —
 * ohne jegliche Anzeige der Stream-Herkunft oder Webadresse.
 */
@Composable
fun LiveTvLightView(
    onPlayInAppPlayer: (ChannelItem) -> Unit,
    isEnglish: Boolean = false
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val allGermanChannels = remember { LiveTvLightCatalog.germanChannels }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("Alle") }
    var resolvingChannelId by remember { mutableStateOf<String?>(null) }

    val categories = remember(allGermanChannels) {
        listOf("Alle") + allGermanChannels.map { it.category }.distinct()
    }

    val filteredChannels = remember(allGermanChannels, searchQuery, selectedCategory) {
        allGermanChannels.filter { ch ->
            val matchesCat = selectedCategory == "Alle" || ch.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                ch.name.contains(searchQuery, ignoreCase = true) ||
                ch.logoBadge.contains(searchQuery, ignoreCase = true) ||
                ch.category.contains(searchQuery, ignoreCase = true)
            matchesCat && matchesSearch
        }
    }

    fun startChannelPlayback(channel: LiveTvLightChannel, externalEngine: PlayerEngine? = null) {
        if (resolvingChannelId != null) return
        resolvingChannelId = channel.id
        coroutineScope.launch {
            try {
                val playableUrl = LiveTvLightStreamResolver.resolvePlayableStream(context, channel)
                val channelItem = channel.toChannelItem(resolvedUrl = playableUrl)
                if (externalEngine != null) {
                    PlayerManager.launchExternalPlayer(
                        context = context,
                        engine = externalEngine,
                        streamUrl = playableUrl,
                        title = channel.name
                    )
                } else {
                    onPlayInAppPlayer(channelItem)
                }
            } finally {
                resolvingChannelId = null
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkNavyBackground)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("live_tv_light_screen")
    ) {
        // Header-Leiste (ohne jeglichen Quellen- oder URL-Hinweis)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
                .border(1.dp, GoldPrimary.copy(alpha = 0.45f), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(GoldPrimary.copy(alpha = 0.15f))
                            .border(1.dp, GoldPrimary.copy(alpha = 0.5f), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LiveTv,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Live TV light • Deutschland",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                        Text(
                            text = if (isEnglish)
                                "${allGermanChannels.size} German Live TV Channels • Direct Player & VLC"
                            else
                                "${allGermanChannels.size} Deutsche Live-Sender • Direkt im Nexus Player & VLC",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AccentEmerald.copy(alpha = 0.16f))
                        .border(1.dp, AccentEmerald.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "DE HD",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        color = AccentEmerald
                    )
                }
            }
        }

        // Suchleiste
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "Clear",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            placeholder = {
                Text(
                    text = if (isEnglish) "Search German channel (e.g. ARD, ZDF, RTL, ProSieben)..." else "Deutschen Sender suchen (z.B. ARD, ZDF, RTL, ProSieben)...",
                    fontSize = 12.sp,
                    color = TextMuted
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("live_tv_light_search"),
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = TextPrimary),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = GoldPrimary,
                unfocusedBorderColor = BorderGlow.copy(alpha = 0.45f),
                focusedContainerColor = DarkSurface,
                unfocusedContainerColor = DarkSurface
            ),
            shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Kategorien-Filter
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            categories.forEach { category ->
                val isSelected = selectedCategory == category
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) GoldPrimary else DarkSurfaceElevated)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) GoldLight else BorderGlow.copy(alpha = 0.3f),
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { selectedCategory = category }
                        .padding(horizontal = 11.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = category,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) ObsidianBlack else TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Sender-Grid mit Logos & direkter Player-Wiedergabe (Nexus Player / VLC / MX)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 165.dp),
            contentPadding = PaddingValues(bottom = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(filteredChannels, key = { it.id }) { channel ->
                LiveTvLightChannelCard(
                    channel = channel,
                    isResolving = resolvingChannelId == channel.id,
                    onPlayDefault = { startChannelPlayback(channel, externalEngine = null) },
                    onPlayWithEngine = { engine -> startChannelPlayback(channel, externalEngine = engine) },
                    isEnglish = isEnglish
                )
            }
        }
    }
}

@Composable
private fun LiveTvLightChannelCard(
    channel: LiveTvLightChannel,
    isResolving: Boolean,
    onPlayDefault: () -> Unit,
    onPlayWithEngine: (PlayerEngine) -> Unit,
    isEnglish: Boolean
) {
    var showPlayerMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, BorderGlow.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .clickable(enabled = !isResolving) { onPlayDefault() }
            .testTag("live_tv_light_card_${channel.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkNavyCard)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Offizielles Sender-Logo mit gestyltem Marken-Fallback
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.95f))
                        .border(1.5.dp, channel.brandColor.copy(alpha = 0.75f), RoundedCornerShape(10.dp))
                        .padding(4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SubcomposeAsyncImage(
                        model = channel.logoUrl,
                        contentDescription = channel.name,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(),
                        error = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(channel.brandColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = channel.logoBadge,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                            }
                        },
                        loading = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(channel.brandColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = channel.logoBadge,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    textAlign = TextAlign.Center,
                                    maxLines = 1
                                )
                            }
                        }
                    )
                }

                // Live-Indikator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(AccentEmerald.copy(alpha = 0.14f))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(AccentEmerald)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "LIVE",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = AccentEmerald
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = channel.name,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = channel.category,
                fontSize = 10.5.sp,
                color = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Direkt im Nexus Player (bzw. Standard-Player) starten
                Button(
                    onClick = onPlayDefault,
                    enabled = !isResolving,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(7.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(32.dp)
                        .testTag("live_tv_light_play_${channel.id}")
                ) {
                    if (isResolving) {
                        CircularProgressIndicator(
                            color = ObsidianBlack,
                            strokeWidth = 2.dp,
                            modifier = Modifier.size(14.dp)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = ObsidianBlack,
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "Player",
                            color = ObsidianBlack,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }

                // Direkt-Wahl für VLC / MX Player / Just Player
                Box {
                    OutlinedButton(
                        onClick = { showPlayerMenu = true },
                        enabled = !isResolving,
                        shape = RoundedCornerShape(7.dp),
                        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("live_tv_light_external_${channel.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SmartDisplay,
                            contentDescription = "VLC / Externer Player",
                            tint = AccentCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "VLC",
                            color = AccentCyan,
                            fontSize = 10.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    DropdownMenu(
                        expanded = showPlayerMenu,
                        onDismissRequest = { showPlayerMenu = false },
                        modifier = Modifier.background(DarkSurfaceElevated)
                    ) {
                        DropdownMenuItem(
                            text = { Text("Nexus Player (Intern)", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            onClick = {
                                showPlayerMenu = false
                                onPlayDefault()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("VLC Player", color = TextPrimary, fontSize = 12.sp) },
                            onClick = {
                                showPlayerMenu = false
                                onPlayWithEngine(PlayerEngine.VLC)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("MX Player", color = TextPrimary, fontSize = 12.sp) },
                            onClick = {
                                showPlayerMenu = false
                                onPlayWithEngine(PlayerEngine.MX_PLAYER)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("XPlayer", color = TextPrimary, fontSize = 12.sp) },
                            onClick = {
                                showPlayerMenu = false
                                onPlayWithEngine(PlayerEngine.XPLAYER)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("MPV Player", color = TextPrimary, fontSize = 12.sp) },
                            onClick = {
                                showPlayerMenu = false
                                onPlayWithEngine(PlayerEngine.MPV)
                            }
                        )
                    }
                }
            }
        }
    }
}
