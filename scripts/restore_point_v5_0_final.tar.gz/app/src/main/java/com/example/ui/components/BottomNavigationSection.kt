package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircleOutline
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.MainTab

@Composable
fun BottomNavigationSection(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit,
    liveCount: Int,
    radioCount: Int = 0,
    movieCount: Int,
    seriesCount: Int,
    isEnglish: Boolean = false
) {
    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding(),
        color = DarkNavyCard,
        tonalElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState)
                .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Live TV mit Sender-Zähler
            BottomNavItem(
                icon = Icons.Default.Tv,
                label = if (isEnglish) "Live TV" else "Live TV",
                count = liveCount,
                isSelected = selectedTab == MainTab.LIVE_TV,
                badgeColor = AccentEmerald,
                testTag = "nav_tab_livetv",
                onClick = { onTabSelected(MainTab.LIVE_TV) }
            )

            // 2. Filme mit Film-Zähler
            BottomNavItem(
                icon = Icons.Default.Movie,
                label = if (isEnglish) "Movies" else "Filme",
                count = movieCount,
                isSelected = selectedTab == MainTab.MOVIES,
                badgeColor = AccentCyan,
                testTag = "nav_tab_movies",
                onClick = { onTabSelected(MainTab.MOVIES) }
            )

            // 3. Serien mit Serien-Zähler
            BottomNavItem(
                icon = Icons.Default.VideoLibrary,
                label = if (isEnglish) "Series" else "Serien",
                count = seriesCount,
                isSelected = selectedTab == MainTab.SERIES,
                badgeColor = GoldLight,
                testTag = "nav_tab_series",
                onClick = { onTabSelected(MainTab.SERIES) }
            )

            // 4. Live TV light (Rechts neben Serien platziert - Deutsche Live-Streams mit Logo)
            BottomNavItem(
                icon = Icons.Default.PlayCircleOutline,
                label = "Live TV light",
                count = null,
                isSelected = selectedTab == MainTab.LIVE_TV_LIGHT,
                badgeColor = AccentEmerald,
                testTag = "nav_tab_livetv_light",
                onClick = { onTabSelected(MainTab.LIVE_TV_LIGHT) }
            )

            // 5. Suche (Globale Suche)
            BottomNavItem(
                icon = Icons.Default.Search,
                label = if (isEnglish) "Search" else "Suche",
                count = null,
                isSelected = selectedTab == MainTab.SEARCH,
                badgeColor = GoldLight,
                testTag = "nav_tab_search",
                onClick = { onTabSelected(MainTab.SEARCH) }
            )

            // 5. Favoriten (Zentrale Favoritenansicht)
            BottomNavItem(
                icon = Icons.Default.Star,
                label = if (isEnglish) "Favorites" else "Favoriten",
                count = null,
                isSelected = selectedTab == MainTab.FAVORITES,
                badgeColor = GoldPrimary,
                testTag = "nav_tab_favorites",
                onClick = { onTabSelected(MainTab.FAVORITES) }
            )

            // 6. Weiter ansehen
            BottomNavItem(
                icon = Icons.Default.PlayArrow,
                label = if (isEnglish) "Resume" else "Fortsetzen",
                count = null,
                isSelected = selectedTab == MainTab.CONTINUE_WATCHING,
                badgeColor = AccentEmerald,
                testTag = "nav_tab_continue",
                onClick = { onTabSelected(MainTab.CONTINUE_WATCHING) }
            )

            // 7. Web Streams / Web TV (2ix2.com & Deutsche Sender)
            BottomNavItem(
                icon = Icons.Default.Language,
                label = if (isEnglish) "Web Streams" else "Web TV",
                count = null,
                isSelected = selectedTab == MainTab.WEB_STREAMS,
                badgeColor = AccentCyan,
                testTag = "nav_tab_webstreams",
                onClick = { onTabSelected(MainTab.WEB_STREAMS) }
            )

            // 8. EPG Guide (Sofortwechsel in Kanal)
            BottomNavItem(
                icon = Icons.Default.CalendarMonth,
                label = "EPG Guide",
                count = null,
                isSelected = selectedTab == MainTab.EPG_GUIDE,
                badgeColor = GoldPrimary,
                testTag = "nav_tab_epg",
                onClick = { onTabSelected(MainTab.EPG_GUIDE) }
            )

            // 9. Einstellungen (Einstellungssymbol)
            BottomNavItem(
                icon = Icons.Default.Settings,
                label = if (isEnglish) "Settings" else "Einstellungen",
                count = null,
                isSelected = selectedTab == MainTab.SETTINGS,
                badgeColor = GoldPrimary,
                testTag = "nav_tab_settings",
                onClick = { onTabSelected(MainTab.SETTINGS) }
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    icon: ImageVector,
    label: String,
    count: Int?,
    isSelected: Boolean,
    badgeColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (isSelected) DarkSurfaceElevated else Color.Transparent
            )
            .border(
                width = if (isSelected) 1.dp else 0.dp,
                color = if (isSelected) GoldPrimary else Color.Transparent,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 5.dp, vertical = 3.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) GoldPrimary else TextSecondary,
                    modifier = Modifier.size(20.dp)
                )

                if (count != null && count > 0) {
                    Box(
                        modifier = Modifier
                            .padding(start = 12.dp, bottom = 2.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(badgeColor)
                            .padding(horizontal = 3.dp, vertical = 0.5.dp)
                    ) {
                        Text(
                            text = if (count > 999) "${count / 1000}k" else "$count",
                            color = Color.Black,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(1.dp))

            Text(
                text = label,
                fontSize = 9.5.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) GoldPrimary else TextSecondary,
                maxLines = 1
            )
        }
    }
}
