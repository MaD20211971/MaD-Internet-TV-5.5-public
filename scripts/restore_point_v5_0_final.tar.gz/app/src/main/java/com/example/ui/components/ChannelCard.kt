package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.parser.ContentClassifier
import com.example.data.model.ChannelItem
import com.example.data.model.EpgProgram
import com.example.data.parser.FreeEpgService
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentRose
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkNavyCard
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ChannelCard(
    channel: ChannelItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
    epgTimezone: String = "Europe/Berlin",
    epgTimeOffsetHours: Int = 0,
    currentProgram: EpgProgram? = null,
    nextProgram: EpgProgram? = null,
    roomPrograms: List<EpgProgram>? = null,
    onInspectCountry: (() -> Unit)? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isFocused = interactionSource.collectIsFocusedAsState().value

    // Auto-update every 30s as broadcast advances
    val currentMinute = (System.currentTimeMillis() / 30000)
    val (currentShow, nextShow) = remember(channel.tvgId, channel.name, epgTimezone, epgTimeOffsetHours, currentMinute, currentProgram, nextProgram, roomPrograms) {
        if (currentProgram != null || nextProgram != null) {
            Pair(currentProgram, nextProgram)
        } else {
            FreeEpgService.getCurrentAndNextProgram(
                tvgId = channel.tvgId,
                channelName = channel.name,
                timezoneId = epgTimezone,
                offsetHours = epgTimeOffsetHours,
                targetTimeMs = System.currentTimeMillis(),
                roomPrograms = roomPrograms
            )
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(
                width = if (isFocused) 2.dp else 1.dp,
                color = when {
                    isFocused -> GoldPrimary
                    channel.isDach -> BorderGlow.copy(alpha = 0.6f)
                    else -> BorderGlow.copy(alpha = 0.2f)
                },
                shape = RoundedCornerShape(14.dp)
            )
            .clickable(interactionSource = interactionSource, indication = null, onClick = onClick)
            .focusable(interactionSource = interactionSource)
            .testTag("channel_item_${channel.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isFocused) DarkSurfaceElevated else DarkSurface
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Channel Logo Box
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ObsidianBlack)
                        .border(1.dp, BorderGlow.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!channel.logoUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = channel.logoUrl,
                            contentDescription = channel.name,
                            modifier = Modifier
                                .size(44.dp)
                                .padding(2.dp),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        // Fallback Initials / Icon
                        val initial = channel.name.take(2).uppercase()
                        Text(
                            text = initial,
                            fontWeight = FontWeight.Black,
                            color = GoldLight,
                            fontSize = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                // Channel Info & Details
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // Country Badge
                        val isAdult = channel.countryCode.uppercase() == "ADULT" || ContentClassifier.isAdultContent(channel.name, channel.groupTitle)
                        val countryText = when {
                            isAdult -> "🔞 18+"
                            channel.countryCode.uppercase() == "DE" -> "🇩🇪 DE"
                            channel.countryCode.uppercase() == "AT" -> "🇦🇹 AT"
                            channel.countryCode.uppercase() == "CH" -> "🇨🇭 CH"
                            channel.countryCode.uppercase() == "EXYU" -> "🇷🇸 EX-YU"
                            channel.countryCode.uppercase() == "TR" -> "🇹🇷 TR"
                            channel.countryCode.uppercase() in listOf("UK", "GB") -> "🇬🇧 UK"
                            channel.countryCode.uppercase() == "US" -> "🇺🇸 US"
                            channel.countryCode.uppercase() == "IT" -> "🇮🇹 IT"
                            channel.countryCode.uppercase() == "FR" -> "🇫🇷 FR"
                            channel.countryCode.uppercase() == "ES" -> "🇪🇸 ES"
                            channel.countryCode.uppercase() == "PL" -> "🇵🇱 PL"
                            channel.countryCode.uppercase() == "NL" -> "🇳🇱 NL"
                            channel.countryCode.uppercase() == "AL" -> "🇦🇱 AL"
                            channel.countryCode.uppercase() == "AR" -> "🇸🇦 AR"
                            channel.countryCode.uppercase() == "RU" -> "🇷🇺 RU"
                            else -> if (channel.isDach) "🇩🇪 DE" else "🌐 INT"
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    when {
                                        isAdult -> AccentRose.copy(alpha = 0.25f)
                                        channel.countryCode.uppercase() in listOf("AT", "CH") -> AccentRose.copy(alpha = 0.2f)
                                        channel.countryCode.uppercase() == "DE" -> GoldPrimary.copy(alpha = 0.2f)
                                        channel.countryCode.uppercase() == "EXYU" -> AccentCyan.copy(alpha = 0.2f)
                                        else -> if (channel.isDach) GoldPrimary.copy(alpha = 0.2f) else DarkNavyCard
                                    }
                                )
                                .then(
                                    if (onInspectCountry != null) {
                                        Modifier
                                            .clickable { onInspectCountry() }
                                            .testTag("inspect_country_${channel.id}")
                                    } else Modifier
                                )
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = countryText,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    isAdult -> AccentRose
                                    channel.countryCode.uppercase() in listOf("AT", "CH") -> AccentRose
                                    channel.countryCode.uppercase() == "DE" -> GoldLight
                                    channel.countryCode.uppercase() == "EXYU" -> AccentCyan
                                    else -> if (channel.isDach) GoldLight else TextSecondary
                                }
                            )
                        }

                        // VIP / Star Badge
                        if (channel.isVip || channel.name.contains("★") || channel.name.contains("⭐") || channel.name.contains("VIP", ignoreCase = true)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(GoldPrimary.copy(alpha = 0.25f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "★ VIP",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldPrimary
                                )
                            }
                        }

                        // 24/7 Badge
                        if (channel.is24_7 || channel.name.contains("24/7", ignoreCase = true) || channel.groupTitle.contains("24/7", ignoreCase = true)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AccentEmerald.copy(alpha = 0.2f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "24/7",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentEmerald
                                )
                            }
                        }

                        // Resolution Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(AccentCyan.copy(alpha = 0.15f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = channel.resolutionBadge,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = AccentCyan
                            )
                        }

                        Text(
                            text = channel.groupTitle,
                            fontSize = 10.sp,
                            color = TextMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = channel.name,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (channel.isFavorite) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AccentRose.copy(alpha = 0.2f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "❤️ FAVORIT",
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentRose
                                )
                            }
                        }
                    }
                }

                // Favorite & Play Actions
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    IconButton(
                        onClick = onToggleFavorite,
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(if (channel.isFavorite) AccentRose.copy(alpha = 0.2f) else Color.Transparent)
                            .testTag("channel_favorite_${channel.id}")
                    ) {
                        Icon(
                            imageVector = if (channel.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = if (channel.isFavorite) "Aus Favoriten entfernen" else "Zu Favoriten hinzufügen",
                            tint = if (channel.isFavorite) AccentRose else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary)
                            .clickable(onClick = onClick)
                            .testTag("channel_play_${channel.id}"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Abspielen",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Live EPG Preview & Progress Bar
            if (currentShow != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(ObsidianBlack.copy(alpha = 0.6f))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(AccentEmerald)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = currentShow.title,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = FreeEpgService.formatProgramTime(currentShow.startTime, epgTimezone),
                                fontSize = 10.sp,
                                color = AccentCyan,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${(currentShow.progress * 100).toInt()}%",
                                fontSize = 10.sp,
                                color = GoldLight,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        LinearProgressIndicator(
                            progress = { currentShow.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp)),
                            color = GoldPrimary,
                            trackColor = BorderGlow.copy(alpha = 0.2f)
                        )

                        if (nextShow != null) {
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "Danach: ${nextShow.title}",
                                fontSize = 10.sp,
                                color = TextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}
