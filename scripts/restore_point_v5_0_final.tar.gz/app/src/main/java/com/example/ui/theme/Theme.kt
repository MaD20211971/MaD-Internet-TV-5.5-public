package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MaDColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color.Black,
    primaryContainer = DarkSurfaceElevated,
    onPrimaryContainer = GoldLight,
    secondary = AccentCyan,
    onSecondary = Color.Black,
    secondaryContainer = DarkSurface,
    onSecondaryContainer = Color.White,
    tertiary = AccentEmerald,
    onTertiary = Color.Black,
    background = ObsidianBlack,
    onBackground = TextPrimary,
    surface = DarkNavyCard,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurface,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    outlineVariant = BorderGlow
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MaDColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MaDInternetTVTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MaDColorScheme,
        typography = Typography,
        content = content
    )
}
